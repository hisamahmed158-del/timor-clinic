const { GoogleGenAI } = require('@google/genai');
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
async function test() {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      tools: [{
        functionDeclarations: [{
          name: "test_func",
          description: "A test function",
          parameters: { type: "OBJECT", properties: { a: { type: "STRING" } } }
        }]
      }]
    }
  });

  let res = await chat.sendMessage("Call test_func with a='hello'");
  console.log("Call 1:", res.functionCalls);

  if (res.functionCalls) {
      try {
          let call = res.functionCalls[0];
          let back = await chat.sendMessage([{
              functionResponse: {
                  id: call.id,
                  name: call.name,
                  response: { result: "world" }
              }
          }]);
          console.log("Call 2:", back.text);
      } catch (e) {
          console.error("Error on function response:", e.message);
      }
  }
}
test();
