import express from "express";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware to parse JSON bodies
  app.use(express.json());

  // Initialize Gemini API
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  const systemInstruction = `أنت مساعد ذكي لعيادة الدكتور تيمور عبد الحليم، أستاذ أمراض القلب والأوعية الدموية.
مهمتك هي الإجابة على استفسارات المرضى بلباقة واحترافية.
معلومات العيادة:
- الطبيب: د. تيمور عبد الحليم (أستاذ أمراض القلب والأوعية الدموية).
- العنوان: المحلة الكبرى - أمام العيادة الشعبية - فوق دار القلب - الدور الثامن.
- مواعيد العمل: يومياً من 5 مساءً حتى 11 مساءً.
- رقم الهاتف: 01006508388
- الخدمات والأسعار:
  * كشف أول: 300 جنيه
  * كشف إعادة: 150 جنيه
  * كشف أول + رسم قلب: 350 جنيه
  * كشف إعادة + رسم قلب: 200 جنيه
إذا سأل المريض عن كيفية الحجز، أخبره أنه يمكنه الحجز من خلال الموقع أو بالاتصال بالعيادة.
أجب باختصار وبشكل مباشر وودود.`;

  // ==========================================
  // WhatsApp Webhook - Verification (GET)
  // ==========================================
  app.get("/webhook/whatsapp", (req, res) => {
    const verify_token = process.env.WHATSAPP_VERIFY_TOKEN;
    
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    if (mode && token) {
      if (mode === "subscribe" && token === verify_token) {
        console.log("WhatsApp Webhook Verified!");
        res.status(200).send(challenge);
      } else {
        res.sendStatus(403);
      }
    } else {
      res.sendStatus(400);
    }
  });

  // ==========================================
  // WhatsApp Webhook - Receive Messages (POST)
  // ==========================================
  app.post("/webhook/whatsapp", async (req, res) => {
    const body = req.body;

    if (body.object) {
      if (
        body.entry &&
        body.entry[0].changes &&
        body.entry[0].changes[0] &&
        body.entry[0].changes[0].value.messages &&
        body.entry[0].changes[0].value.messages[0]
      ) {
        const phoneNumberId = body.entry[0].changes[0].value.metadata.phone_number_id;
        const from = body.entry[0].changes[0].value.messages[0].from; // Sender's phone number
        const msgBody = body.entry[0].changes[0].value.messages[0].text?.body; // The text message

        if (msgBody) {
          console.log(`Received WhatsApp message from ${from}: ${msgBody}`);

          try {
            // 1. Send message to Gemini API
            const chat = ai.chats.create({
              model: "gemini-3-flash-preview",
              config: { systemInstruction }
            });
            const aiResponse = await chat.sendMessage({ message: msgBody });
            const replyText = aiResponse.text || "عذراً، لم أتمكن من فهم طلبك.";

            // 2. Send reply back to WhatsApp
            const token = process.env.WHATSAPP_TOKEN;
            if (token) {
              await fetch(`https://graph.facebook.com/v17.0/${phoneNumberId}/messages`, {
                method: "POST",
                headers: {
                  "Authorization": `Bearer ${token}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  messaging_product: "whatsapp",
                  to: from,
                  text: { body: replyText },
                }),
              });
              console.log("Reply sent to WhatsApp successfully.");
            } else {
              console.error("WHATSAPP_TOKEN is not set in environment variables.");
            }
          } catch (error) {
            console.error("Error processing WhatsApp message:", error);
          }
        }
      }
      res.sendStatus(200);
    } else {
      res.sendStatus(404);
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
