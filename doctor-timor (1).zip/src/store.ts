import { db, auth } from './firebase';
import { collection, doc, setDoc, updateDoc, deleteDoc, getDoc, getDocs } from 'firebase/firestore';

export interface Booking {
  id: number;
  ref: string;
  name: string;
  phone: string;
  age: string;
  address?: string;
  service: string;
  serviceName: string;
  price: number;
  payment: string;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  cancelReason: string;
  secretaryReply?: string;
  createdAt: string;
  queue: number | null;
  source?: string;
  uid?: string; // Firebase Owner UID
}

export interface User {
  id?: number;
  name: string;
  email: string;
  pass?: string;
  role: 'doctor' | 'secretary';
}

export interface Call {
  name: string;
  phone: string;
  notes: string;
  time: string;
}

export interface Patient {
  id: string;
  name: string;
  phone: string;
  age: string;
  diagnosis: string;
  treatment: string;
  lastVisit?: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  date: string;
  createdAt: string;
  addedBy: string;
}

export interface Exception {
  status: string;
  start: string;
  end: string;
}

export interface QueueData {
  cNum: string | number;
  cName: string;
  nNum: string | number;
  nName: string;
}

const getLocalToday = () => {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
};

const normalizeDate = (dStr: string) => {
  if (!dStr) return '';
  if (dStr === 'اليوم' || dStr === 'النهاردة' || dStr === 'النهارده') {
     return getLocalToday();
  }
  const parts = dStr.split(/[-/]/);
  if (parts.length === 3) {
     if (parts[2].length === 4) return `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
     if (parts[0].length === 4) return `${parts[0]}-${parts[1].padStart(2,'0')}-${parts[2].padStart(2,'0')}`;
  }
  return dStr;
};

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const normalizeSearchKey = (text: string) => {
  if (!text) return '';
  return text.trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[ًٌٍَُِّْ]/g, '')
    .replace(/٠/g, '0').replace(/١/g, '1').replace(/٢/g, '2')
    .replace(/٣/g, '3').replace(/٤/g, '4').replace(/٥/g, '5')
    .replace(/٦/g, '6').replace(/٧/g, '7').replace(/٨/g, '8').replace(/٩/g, '9')
    .toLowerCase()
    .replace(/[^a-z0-9\u0600-\u06FF]/g, ''); // Removes spaces, punctuation, symbols (e.g. slashes)
};

export const createFirebaseBooking = async (b: Booking) => {
  try {
    const submitPromise = async () => {
      await setDoc(doc(db, 'bookings', b.ref), b);
      if (b.phone) {
        const safePhone = normalizeSearchKey(b.phone);
        if (safePhone) setDoc(doc(db, 'booking_idx_phone', safePhone), { ref: b.ref }).catch(e => console.error(e));
      }
      if (b.name) {
        const safeName = normalizeSearchKey(b.name);
        if (safeName) setDoc(doc(db, 'booking_idx_name', safeName), { ref: b.ref }).catch(e => console.error(e));
      }
    };

    await Promise.race([
      submitPromise(),
      new Promise((_, reject) => setTimeout(() => reject(new Error("⚠️ ضعف في الاتصال بالإنترنت، استغرق الإرسال وقتاً طويلاً. يرجى التحقق من الشبكة والمحاولة مرة أخرى.")), 15000))
    ]);
  } catch (error: any) {
    if (error.message && error.message.includes("ضعف في الاتصال")) {
      throw error;
    }
    handleFirestoreError(error, OperationType.CREATE, 'bookings');
  }
};

export const updateFirebaseBooking = async (ref: string, data: Partial<Booking>) => {
  try {
    await updateDoc(doc(db, 'bookings', ref), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `bookings/${ref}`);
  }
};

export const addFirebaseUser = async (email: string, data: Partial<User>) => {
  try {
    await setDoc(doc(db, 'users', email), data);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `users/${email}`);
  }
};

export const deleteFirebaseUser = async (email: string) => {
  try {
    await deleteDoc(doc(db, 'users', email));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${email}`);
  }
};

export const saveFirebasePatient = async (p: Patient) => {
  try {
    await setDoc(doc(db, 'patients', p.id), p);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `patients/${p.id}`);
  }
};

export const deleteFirebasePatient = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'patients', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `patients/${id}`);
  }
};

export const saveFirebaseExpense = async (e: Expense) => {
  try {
    await setDoc(doc(db, 'expenses', e.id), e);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `expenses/${e.id}`);
  }
};

export const deleteFirebaseExpense = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'expenses', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `expenses/${id}`);
  }
};

export const deleteFirebaseBooking = async (ref: string) => {
  try {
    await deleteDoc(doc(db, 'bookings', ref));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `bookings/${ref}`);
  }
};

export const getBookings = (): Booking[] => {
  const stored = localStorage.getItem('cl_b5') || '[]';
  const bks: Booking[] = JSON.parse(stored);
  const todayStr = getLocalToday();
  
  // الاحتفاظ فقط بالطلبات التي تاريخها اليوم أو في المستقبل
  const updated = bks.filter(b => normalizeDate(b.date) >= todayStr);
  
  if (updated.length !== bks.length) {
    localStorage.setItem('cl_b5', JSON.stringify(updated));
  }
  return updated;
};
export const saveBookings = (b: Booking[]) => localStorage.setItem('cl_b5', JSON.stringify(b));

export const getUsers = (): User[] => {
  const users = JSON.parse(localStorage.getItem('cl_u5') || '[]');
  if (!users.length) {
    const defaultUsers: User[] = [
      { id: 1, name: 'الدكتور', email: 'doctor@clinic.com', pass: 'clinic2026', role: 'doctor' },
      { id: 2, name: 'السكرتيرة', email: 'secretary@clinic.com', pass: 'clinic2026', role: 'secretary' }
    ];
    localStorage.setItem('cl_u5', JSON.stringify(defaultUsers));
    return defaultUsers;
  }
  return users;
};
export const saveUsers = (u: User[]) => localStorage.setItem('cl_u5', JSON.stringify(u));

export const getCalls = (): Call[] => JSON.parse(localStorage.getItem('cl_c5') || '[]');
export const saveCalls = (c: Call[]) => localStorage.setItem('cl_c5', JSON.stringify(c));

export const getExceptions = (): Record<string, Exception> => JSON.parse(localStorage.getItem('cl_hours') || '{}');
export const saveExceptions = (e: Record<string, Exception>) => localStorage.setItem('cl_hours', JSON.stringify(e));

export const getQueueData = (): QueueData => JSON.parse(localStorage.getItem('cl_q') || '{"cNum":"-","cName":"-","nNum":"-","nName":"-"}');
export const saveQueueData = (q: QueueData) => localStorage.setItem('cl_q', JSON.stringify(q));
