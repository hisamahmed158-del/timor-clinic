import React, { useState, useEffect } from 'react';
import { PublicPages } from './components/PublicPages';
import { BookingSection } from './components/BookingSection';
import { FloatingButtons } from './components/FloatingButtons';
import { QueueScreen } from './components/QueueScreen';
import { ChatBot } from './components/ChatBot';
import { LoginModal, QueuePasswordModal, BookingChoiceModal } from './components/Modals';
import { AdminPanel } from './components/AdminPanel';
import { User } from './store';

export default function App() {
  const [notification, setNotification] = useState<{ msg: string, err: boolean } | null>(null);
  const [showLogin, setShowLogin] = useState(false);
  const [showQueuePassword, setShowQueuePassword] = useState(false);
  const [showQueueScreen, setShowQueueScreen] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showBookingChoice, setShowBookingChoice] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const notify = (msg: string, err: boolean = false) => {
    setNotification({ msg, err });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleGoToForm = () => {
    setShowBookingChoice(false);
    const bookingSection = document.getElementById('booking');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleGoToBot = () => {
    setShowBookingChoice(false);
    setShowChat(true);
  };

  return (
    <>
      <div className={`fixed top-5 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full font-bold text-sm text-white z-[99999] transition-all duration-300 pointer-events-none ${notification ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-5'} ${notification?.err ? 'bg-accent' : 'bg-[#2ecc71]'}`}>
        {notification?.msg}
      </div>

      {!currentUser ? (
        <>
          <PublicPages 
            onOpenLogin={() => setShowLogin(true)} 
            onOpenQueue={() => setShowQueuePassword(true)} 
            onOpenChat={() => setShowChat(true)} 
            onOpenBookingChoice={() => setShowBookingChoice(true)}
          />
          <BookingSection onNotify={notify} />
          
          <section id="contact" className="p-8 max-w-6xl mx-auto">
            <div className="text-center font-black text-2xl mb-5 text-[#1a1a2e]">تواصل معنا</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="bg-white p-4 rounded-xl text-center shadow-sm">
                <i className="fas fa-phone text-3xl text-primary mb-2"></i><h3 className="font-bold">اتصل بالعيادة</h3><p className="font-bold text-primary" dir="ltr">01006508388</p>
              </div>
              <div className="bg-white p-4 rounded-xl text-center shadow-sm">
                <i className="fab fa-whatsapp text-3xl text-[#25d366] mb-2"></i><h3 className="font-bold">واتساب</h3><a href="https://wa.me/201006508388?text=اريد%20حجز%20موعد" target="_blank" rel="noreferrer" className="font-bold text-[#25d366] no-underline">مراسلة فورية</a>
              </div>
              <div className="bg-white p-4 rounded-xl text-center shadow-sm">
                <i className="fas fa-map-marker-alt text-3xl text-accent mb-2"></i><h3 className="font-bold">العنوان</h3><p className="text-sm">المحلة الكبرى - أمام العيادة الشعبية<br/>فوق دار القلب - الدور الثامن</p>
              </div>
            </div>
          </section>

          <footer className="bg-[#1a1a2e] text-white text-center p-4 text-xs mt-5">© 2026 عيادة د. تيمور عبد الحليم</footer>

          <FloatingButtons 
             onOpenQueue={() => setShowQueuePassword(true)} 
             onOpenChat={() => setShowChat(true)} 
             onOpenBookingChoice={() => setShowBookingChoice(true)}
          />
        </>
      ) : (
        <AdminPanel user={currentUser} onLogout={() => setCurrentUser(null)} onNotify={notify} />
      )}

      {showLogin && <LoginModal onClose={() => setShowLogin(false)} onLogin={(u) => { setCurrentUser(u); setShowLogin(false); }} />}
      {showQueuePassword && (
        <QueuePasswordModal 
          onClose={() => setShowQueuePassword(false)} 
          onConfirm={() => {
            setShowQueuePassword(false);
            setShowQueueScreen(true);
          }} 
        />
      )}
      {showQueueScreen && <QueueScreen onClose={() => setShowQueueScreen(false)} />}
      {showChat && <ChatBot onClose={() => setShowChat(false)} onNotify={notify} />}
      {showBookingChoice && <BookingChoiceModal onClose={() => setShowBookingChoice(false)} onGoToForm={handleGoToForm} onGoToBot={handleGoToBot} />}
    </>
  );
}
