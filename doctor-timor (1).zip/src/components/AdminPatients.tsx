import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import { Patient, saveFirebasePatient, deleteFirebasePatient, normalizeSearchKey } from '../store';

export function AdminPatients({ onNotify }: { onNotify: (m: string, e?: boolean) => void }) {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [search, setSearch] = useState('');
  
  const [form, setForm] = useState<Partial<Patient>>({});
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'patients'), (snap) => {
      const p: Patient[] = [];
      snap.forEach(d => p.push(d.data() as Patient));
      setPatients(p.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    });
    return () => unsub();
  }, []);

  const handleSave = async () => {
    if (!form.name || !form.phone) {
      onNotify('يرجى إدخال اسم المريض ورقم الهاتف', true);
      return;
    }
    setIsLoading(true);
    try {
      const id = form.id || 'PAT-' + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase();
      const newP: Patient = {
        id,
        name: form.name.trim(),
        phone: form.phone.trim(),
        age: form.age || '',
        diagnosis: form.diagnosis || '',
        treatment: form.treatment || '',
        lastVisit: form.lastVisit || new Date().toISOString().split('T')[0],
        createdAt: form.createdAt || new Date().toISOString()
      };
      await saveFirebasePatient(newP);
      onNotify('تم حفظ بيانات المريض بنجاح');
      setShowModal(false);
      setForm({});
    } catch(e: any) {
      onNotify(e.message || 'خطأ في الحفظ', true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (window.confirm(`هل أنت متأكد من حذف المريض ${name} وكل بياناته؟`)) {
       await deleteFirebasePatient(id);
       onNotify('تم الحذف');
    }
  };

  const openAdd = () => {
    setForm({ lastVisit: new Date().toISOString().split('T')[0] });
    setShowModal(true);
  };

  const openEdit = (p: Patient) => {
    setForm(p);
    setShowModal(true);
  };

  const filtered = patients.filter(p => {
    if (!search) return true;
    const q = normalizeSearchKey(search);
    const n = normalizeSearchKey(p.name);
    const ph = normalizeSearchKey(p.phone);
    return n.includes(q) || ph.includes(q);
  });

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 min-h-[60vh]">
      <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
        <h3 className="font-extrabold text-xl text-primary"><i className="fas fa-users-medical"></i> سجل المرضى الطبي</h3>
        <button className="bg-[#2ecc71] hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg shadow-sm border-none cursor-pointer flex items-center gap-2 transition-colors" onClick={openAdd}>
          <i className="fas fa-user-plus"></i> مريض جديد
        </button>
      </div>

      <div className="mb-4">
        <div className="relative">
          <input 
            type="text" 
            placeholder="بحث بالاسم أو رقم الهاتف..." 
            className="w-full p-3 pr-10 border border-gray-300 rounded-lg outline-none focus:border-primary"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <i className="fas fa-search absolute right-3 top-3.5 text-gray-400"></i>
        </div>
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-gray-500">لا يوجد مرضى مطابقين للبحث.</div>
        ) : (
          filtered.map((p) => (
            <div key={p.id} className="border border-gray-200 rounded-lg p-3 hover:border-primary transition-colors flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
              <div>
                <div className="font-bold text-lg">{p.name} <span className="text-sm font-normal text-gray-500">({p.age ? p.age + ' سنة' : 'غير محدد السن'})</span></div>
                <div className="text-sm text-gray-600 mb-1"><i className="fas fa-phone text-xs"></i> <span dir="ltr">{p.phone}</span></div>
                {p.lastVisit && <div className="text-xs text-blue-600 font-bold mb-1">📅 آخر زيارة: {p.lastVisit}</div>}
              </div>

              <div className="flex-1 bg-gray-50 p-2 rounded text-sm min-w-0 w-full">
                 <div className="mb-1"><span className="font-bold text-accent">تشخيص الحالة: </span>{p.diagnosis || <span className="text-gray-400 text-xs">لم يكتب بعد</span>}</div>
                 <div><span className="font-bold text-[#2ecc71]">العلاج (الروشتة): </span>{p.treatment || <span className="text-gray-400 text-xs">لم يكتب بعد</span>}</div>
              </div>

              <div className="flex gap-2 w-full md:w-auto mt-2 md:mt-0">
                 <button onClick={() => openEdit(p)} className="flex-1 md:flex-none bg-blue-50 text-blue-600 hover:bg-blue-100 border-none px-3 py-1.5 rounded font-bold cursor-pointer transition-colors text-sm"><i className="fas fa-edit"></i> تعديل</button>
                 <button onClick={() => handleDelete(p.id, p.name)} className="flex-1 md:flex-none bg-red-50 text-red-600 hover:bg-red-100 border-none px-3 py-1.5 rounded font-bold cursor-pointer transition-colors text-sm"><i className="fas fa-trash"></i></button>
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/60 z-[9999] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-xl max-h-[95vh] overflow-y-auto" dir="rtl">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl">
              <h3 className="font-extrabold text-lg m-0">{form.id ? '✏️ تعديل بيانات مريض' : '➕ إضافة مريض جديد'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-red-500 bg-transparent border-none text-xl cursor-pointer"><i className="fas fa-times"></i></button>
            </div>
            <div className="p-5 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-bold mb-1 text-gray-700">الاسم بالكامل <span className="text-red-500">*</span></label>
                  <input type="text" className="w-full p-2 border border-gray-300 rounded focus:border-primary outline-none" value={form.name || ''} onChange={(e)=>setForm({...form, name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-1 text-gray-700">رقم الهاتف <span className="text-red-500">*</span></label>
                  <input type="text" className="w-full p-2 border border-gray-300 rounded focus:border-primary outline-none text-left" dir="ltr" value={form.phone || ''} onChange={(e)=>setForm({...form, phone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-1 text-gray-700">السن</label>
                  <input type="number" className="w-full p-2 border border-gray-300 rounded focus:border-primary outline-none" value={form.age || ''} onChange={(e)=>setForm({...form, age: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-1 text-gray-700">تاريخ آخر زيارة</label>
                  <input type="date" className="w-full p-2 border border-gray-300 rounded focus:border-primary outline-none" value={form.lastVisit || ''} onChange={(e)=>setForm({...form, lastVisit: e.target.value})} />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold mb-1 text-accent">تشخيص الحالة</label>
                <textarea className="w-full p-2 border border-gray-300 rounded focus:border-primary outline-none min-h-[80px]" placeholder="اكتب تشخيص وتاريخ المريض المرضي..." value={form.diagnosis || ''} onChange={(e)=>setForm({...form, diagnosis: e.target.value})}></textarea>
              </div>

              <div>
                <label className="block text-sm font-bold mb-1 text-[#2ecc71]">العلاج (الروشتة)</label>
                <textarea className="w-full p-2 border border-gray-300 rounded focus:border-primary outline-none min-h-[80px]" placeholder="الأدوية وطرق العلاج المُوصى بها..." value={form.treatment || ''} onChange={(e)=>setForm({...form, treatment: e.target.value})}></textarea>
              </div>
            </div>
            
            <div className="p-4 border-t border-gray-100 bg-gray-50 rounded-b-xl flex justify-end gap-2">
              <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded font-bold cursor-pointer border-none hover:bg-gray-300" onClick={() => setShowModal(false)} disabled={isLoading}>إلغاء</button>
              <button className="px-4 py-2 bg-primary text-white rounded font-bold cursor-pointer border-none hover:bg-primary-dark disabled:opacity-50" onClick={handleSave} disabled={isLoading}>
                 {isLoading ? 'جاري الحفظ...' : 'حفظ البيانات'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
