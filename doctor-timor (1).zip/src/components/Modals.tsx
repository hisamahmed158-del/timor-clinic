import React, { useState } from 'react';
import { User } from '../store';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';

export function BookingChoiceModal({ onClose, onGoToForm, onGoToBot }: { onClose: () => void, onGoToForm: () => void, onGoToBot: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-6 w-[90%] max-w-[400px] text-center shadow-xl border-t-8 border-primary">
        <h3 className="font-extrabold text-2xl mb-2 text-[#1a1a2e]">كيف تود الحجز؟</h3>
        <p className="mb-6 text-sm text-gray-500">اختر الطريقة الأسهل لك للحجز أو الاستعلام</p>
        
        <button onClick={onGoToBot} className="w-full p-4 border border-purple-200 rounded-xl font-bold cursor-pointer font-sans bg-purple-50 text-purple-700 mb-3 hover:bg-purple-100 flex items-center justify-center gap-3 transition-colors group">
          <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
            <i className="fas fa-robot text-xl"></i>
          </div>
          <span className="text-lg">عبر المساعد الذكي</span>
        </button>

        <button onClick={onGoToForm} className="w-full p-4 border border-blue-200 rounded-xl font-bold cursor-pointer font-sans bg-blue-50 text-primary mb-5 hover:bg-blue-100 flex items-center justify-center gap-3 transition-colors group">
           <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
            <i className="fas fa-list-alt text-xl"></i>
          </div>
          <span className="text-lg">عبر نموذج الحجز اليدوي</span>
        </button>

        <button className="w-full p-3 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors" onClick={onClose}>إلغاء</button>
      </div>
    </div>
  );
}

export function LoginModal({ onClose, onLogin }: { onClose: () => void, onLogin: (u: User) => void }) {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      const email = result.user.email?.toLowerCase();
      
      if (!email) {
        setLoading(false);
        return;
      }

      const snap = await getDoc(doc(db, 'users', email));
      if (snap.exists()) {
        const ud = snap.data() as User;
        onLogin({ id: Date.now(), name: ud.name, email, role: ud.role });
      } else if (email === 'hisamahmed158@gmail.com') {
        const adminData: User = { name: 'د. تيمور عبد الحليم', email, role: 'doctor' };
        try {
          const { setDoc } = await import('firebase/firestore');
          await setDoc(doc(db, 'users', email), adminData);
        } catch (e) {
          console.warn("Bootstrap write failed", e);
        }
        onLogin({ id: 999, ...adminData });
      } else {
        alert(`تم تسجيل الدخول كـ ${email} ولكن ليس لديك صلاحية الدخول كإدارة. يرجى التواصل مع الطبيب لإضافة إيميلك.`);
        auth.signOut();
      }
    } catch (error: any) {
      console.error(error);
      if (error.code !== 'auth/popup-closed-by-user') {
        alert('فشل تسجيل الدخول بواسطة جوجل.');
      }
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-5 w-[90%] max-w-[400px] text-center">
        <h3 className="font-extrabold text-xl mb-4 text-primary">🏥 إدارة العيادة</h3>
        <p className="mb-4 text-sm text-gray-600">يرجى تسجيل الدخول بحساب جوجل للوصول إلى لوحة التحكم بصلاحياتك المعينة.</p>
        
        <button onClick={handleGoogleLogin} disabled={loading} className="w-full p-3 border border-gray-300 rounded-lg font-bold cursor-pointer font-sans bg-white text-gray-800 mb-4 hover:bg-gray-50 flex items-center justify-center gap-3 transition-colors shadow-sm disabled:opacity-50">
          {loading ? (
             <span className="w-6 h-6 border-4 border-gray-300 border-t-primary rounded-full animate-spin"></span>
          ) : (
             <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
          )}
          {loading ? 'جاري الدخول...' : 'تسجيل الدخول باستخدام جوجل'}
        </button>
        <button className="w-full p-3 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors" onClick={onClose}>رجوع</button>
      </div>
    </div>
  );
}

export function CancelModal({ onClose, onConfirm }: { onClose: () => void, onConfirm: (reason: string) => void }) {
  const [reason, setReason] = useState('');
  const [otherReason, setOtherReason] = useState('');

  const handleConfirm = () => {
    let finalReason = reason;
    if (reason === 'سبب آخر') {
      if (!otherReason.trim()) { alert('اكتب السبب'); return; }
      finalReason = otherReason;
    }
    if (!finalReason) { alert('اختر السبب'); return; }
    onConfirm(finalReason);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-5 w-[90%] max-w-[400px] text-center">
        <h3 className="font-extrabold text-xl mb-2 text-accent">❌ إلغاء الموعد</h3>
        <p className="mb-4 text-sm">حدد سبب الإلغاء:</p>
        <select className="w-full p-2 border border-gray-300 rounded-md mb-4 font-sans" value={reason} onChange={e => setReason(e.target.value)}>
          <option value="">اختر السبب...</option>
          <option value="طلب المريض">طلب من المريض</option>
          <option value="تغيير الموعد">رغبة في تغيير الموعد</option>
          <option value="عدم الحضور">عدم الحضور</option>
          <option value="ظروف الطبيب">ظروف خاصة بالطبيب</option>
          <option value="سبب آخر">سبب آخر</option>
        </select>
        {reason === 'سبب آخر' && (
          <input type="text" className="w-full p-2 border border-gray-300 rounded-md mb-4 font-sans" placeholder="اكتب السبب بالتفصيل..." value={otherReason} onChange={e => setOtherReason(e.target.value)} />
        )}
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-accent text-white mb-2 hover:bg-red-600 transition-colors" onClick={handleConfirm}>تأكيد الإلغاء</button>
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors" onClick={onClose}>رجوع</button>
      </div>
    </div>
  );
}

export function EditModal({ service, onClose, onConfirm }: { service: string, onClose: () => void, onConfirm: (s: string) => void }) {
  const [newService, setNewService] = useState(service);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-5 w-[90%] max-w-[400px] text-center">
        <h3 className="font-extrabold text-xl mb-4 text-primary">✏️ تعديل الخدمة</h3>
        <select className="w-full p-2 border border-gray-300 rounded-md mb-4 font-sans" value={newService} onChange={e => setNewService(e.target.value)}>
          <option value="first-only">كشف أول فقط (300)</option>
          <option value="first-ecg">كشف أول + رسم قلب (350)</option>
          <option value="follow-only">كشف إعادة فقط (150)</option>
          <option value="follow-ecg">كشف إعادة + رسم قلب (200)</option>
        </select>
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-primary text-white mb-2 hover:bg-primary-dark transition-colors" onClick={() => onConfirm(newService)}>حفظ التعديل</button>
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors" onClick={onClose}>إغلاق</button>
      </div>
    </div>
  );
}

export function CallModal({ onClose, onSave }: { onClose: () => void, onSave: (n: string, p: string, notes: string) => void }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');

  const handleSave = () => {
    if (!name || !phone) { alert('أكمل البيانات'); return; }
    onSave(name, phone, notes);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-5 w-[90%] max-w-[400px] text-center">
        <h3 className="font-extrabold text-xl mb-4 text-[#2ecc71]">📞 تسجيل مكالمة</h3>
        <input type="text" className="w-full p-2 border border-gray-300 rounded-md mb-2 font-sans" placeholder="اسم المريض" value={name} onChange={e => setName(e.target.value)} />
        <input type="tel" className="w-full p-2 border border-gray-300 rounded-md mb-2 font-sans text-left" dir="ltr" placeholder="الهاتف" value={phone} onChange={e => setPhone(e.target.value)} />
        <input type="text" className="w-full p-2 border border-gray-300 rounded-md mb-4 font-sans" placeholder="ملاحظات" value={notes} onChange={e => setNotes(e.target.value)} />
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-[#2ecc71] text-white mb-2 hover:bg-green-600 transition-colors" onClick={handleSave}>حفظ</button>
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors" onClick={onClose}>إغلاق</button>
      </div>
    </div>
  );
}

export function ReplyModal({ onClose, onConfirm }: { onClose: () => void, onConfirm: (reply: string) => void }) {
  const [reply, setReply] = useState('');

  const handleConfirm = () => {
    if (!reply.trim()) { alert('اكتب الرد'); return; }
    onConfirm(reply);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-5 w-[90%] max-w-[400px] text-center">
        <h3 className="font-extrabold text-xl mb-4 text-primary">💬 إضافة رد للمريض</h3>
        <p className="mb-4 text-sm text-gray-600">سيقوم المساعد الذكي بقراءة هذا الرد للمريض عند استعلامه عن حجزه.</p>
        <textarea 
          className="w-full p-2 border border-gray-300 rounded-md mb-4 font-sans min-h-[100px]" 
          placeholder="اكتب رد السكرتيرة هنا..." 
          value={reply} 
          onChange={e => setReply(e.target.value)} 
        />
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-primary text-white mb-2 hover:bg-primary-dark transition-colors" onClick={handleConfirm}>حفظ الرد</button>
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors" onClick={onClose}>رجوع</button>
      </div>
    </div>
  );
}

export function QueuePasswordModal({ onClose, onConfirm }: { onClose: () => void, onConfirm: () => void }) {
  const [pass, setPass] = useState('');

  const handleConfirm = () => {
    if (pass === 'doctor123' || pass === '2468') {
      onConfirm();
    } else {
      alert('كلمة المرور خاطئة');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-xl p-5 w-[90%] max-w-[400px] text-center">
        <h3 className="font-extrabold text-xl mb-4 text-[#6c5ce7]">🔐 دخول شاشة الانتظار</h3>
        <p className="mb-4 text-sm">هذه الشاشة مخصصة للطبيب فقط. يرجى إدخال كلمة المرور:</p>
        <input 
          type="password" 
          className="w-full p-2 border border-gray-300 rounded-md mb-4 font-sans text-center" 
          placeholder="كلمة المرور" 
          value={pass} 
          onChange={e => setPass(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleConfirm()}
          autoFocus
        />
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-[#6c5ce7] text-white mb-2 hover:bg-[#5b4bc4] transition-colors" onClick={handleConfirm}>دخول</button>
        <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors" onClick={onClose}>إلغاء</button>
      </div>
    </div>
  );
}
