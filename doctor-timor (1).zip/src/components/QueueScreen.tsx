import React, { useState, useEffect } from 'react';
import { getQueueData, QueueData } from '../store';

export function QueueScreen({ onClose }: { onClose: () => void }) {
  const [queueData, setQueueData] = useState<QueueData>(getQueueData());

  useEffect(() => {
    const interval = setInterval(() => {
      setQueueData(getQueueData());
    }, 3000);
    
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'cl_q') {
        setQueueData(getQueueData());
      }
    };
    window.addEventListener('storage', handleStorage);
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', handleStorage);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-gradient-queue text-white z-[5000] flex flex-col p-8 overflow-hidden">
      <div className="flex justify-between items-center pb-4 border-b-2 border-white/20 mb-8">
        <div className="flex items-center gap-4">
          <div className="text-2xl font-bold"><i className="fas fa-clinic-medical mr-2"></i> عيادة د. تيمور عبد الحليم</div>
          <span className="bg-accent text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">شاشة الطبيب الخاصة</span>
        </div>
        <button className="bg-white/20 border-none text-white w-10 h-10 rounded-full cursor-pointer text-xl transition-colors hover:bg-accent flex items-center justify-center" onClick={onClose}>
          <i className="fas fa-times"></i>
        </button>
      </div>
      
      <div className="flex-1 flex justify-center items-center gap-16 flex-wrap">
        <div className="bg-gradient-primary border-2 border-primary shadow-[0_0_30px_rgba(13,110,253,0.5)] rounded-2xl p-8 min-w-[280px] text-center transition-transform hover:scale-105">
          <div className="text-lg opacity-90 mb-2">🔴 الدور الحالي</div>
          <div className="text-[6rem] font-black my-2 leading-none animate-popIn">{queueData.cNum || '--'}</div>
          <div className="text-2xl font-semibold mt-2 min-h-[2rem]">{queueData.cName || '--'}</div>
        </div>
        
        <div className="bg-white/10 border-2 border-white/20 backdrop-blur-md rounded-2xl p-8 min-w-[280px] text-center transition-transform hover:scale-105">
          <div className="text-lg opacity-90 mb-2">🟡 الدور القادم</div>
          <div className="text-[5rem] font-black my-2 leading-none">{queueData.nNum || '--'}</div>
          <div className="text-2xl font-semibold mt-2 min-h-[2rem]">{queueData.nName || '--'}</div>
        </div>
      </div>
      
      <div className="text-center pt-4 opacity-70 text-sm mt-auto">
        <div className="flex items-center justify-center gap-2 text-[#2ecc71] font-semibold mb-2">
          <span className="w-2.5 h-2.5 bg-[#2ecc71] rounded-full animate-pulse-green"></span> تحديث مباشر
        </div>
        <div>مواعيد العمل: 5 مساءً - 11 مساءً</div>
      </div>
    </div>
  );
}
