import React, { useState, useEffect, useRef } from 'react';
import { Booking, createFirebaseBooking, normalizeSearchKey } from '../store';
import { db, auth } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';
import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

const systemInstruction = `أنت مساعد ذكي لعيادة الدكتور تيمور عبد الحليم، أستاذ أمراض القلب والأوعية الدموية.
مهمتك هي الإجابة على استفسارات المرضى الإدارية فقط وإدارة الحجوزات بلهجة مصرية عامية لطيفة جداً ومرحة ومحترمة (زي المساعدين الطبيين الشاطرين في مصر).
معلومات العيادة:
- الدكتور: د. تيمور عبد الحليم (أستاذ أمراض القلب والأوعية الدموية).
- العنوان: المحلة الكبرى - قدام العيادة الشعبية - فوق دار القلب - الدور التامن.
- مواعيد الشغل: كل يوم من 5 مساءً لحد 11 مساءً.
- رقم التليفون: 01006508388
- الكشوفات والأسعار (لازم المريض يختار حاجة منها):
  * كشف أول: 300 جنيه (معرفها: first-only)
  * كشف إعادة: 150 جنيه (معرفها: follow-only)
  * كشف أول + رسم قلب: 350 جنيه (معرفها: first-ecg)
  * كشف إعادة + رسم قلب: 200 جنيه (معرفها: follow-ecg)

مهماتك:
1. المنع البات للأسئلة الطبية: ممنوع منعاً باتاً الإجابة على أي أسئلة طبية، تشخيص أعراض، أو نصائح طبية أو وصف أدوية. إذا سألك المريض أي سؤال طبي (مهما كان بسيط)، اعتذر بلطف جداً وقوله إنك مجرد مساعد إداري ومينفعش إطلاقاً ترد على أي أسئلة طبية حفاظاً على صحته، واعرض عليه فوراً إنك تحجزله كشف عشان الدكتور تيمور يقدر يفيده بشكل طبي سليم ومظبوط.
2. إزاي تحجز للمريض: لو المريض عايز يحجز، اطلب منه البيانات دي بالراحة وبطريقة ودودة ومش كلها مرة واحدة: (الاسم بالكامل، رقم التليفون، السن، العنوان، نوع الكشف، تاريخ الحجز، وقت الحجز، وهيدفع إزاي؟ كاش، فيزا، محفظة، ولا إنستاباي).
**تحذير هام جداً**: أول ما تجمع كل البيانات، إياك أن تخترع رقم طلب من نفسك في الرد! يجب عليك إجبارياً استخدام أداة \`book_appointment\` في مخرجاتك. هذه الأداة هي التي ستسجل الطلب فعلياً في قاعدة بيانات العيادة وسترجع لك "رقم الطلب" (زي REQ-XXXX). بعد أن تقوم الأداة بإرجاع الرقم، يمكنك إخبار المريض به وتوضيح أن الحجز "قيد المراجعة" والسكرتيرة هتأكده إن شاء الله.
3. الاستعلام عن الحجز: لو حد سأل على حجزه، اطلب منه يكتبلك رقم الطلب اللي بيبدأ بـ REQ- أو اسمه بالكامل أو رقم الموبايل. استخدم أداة \`check_booking_status\` عشان تتأكد، وبعدين قوله النتيجة. **تحذير**: لا تؤلف أي نتيجة من عندك بدون استخدام الأداة.
ملاحظة مهمة جداً للاستعلام: لو الأداة رجعتلك حاجة اسمها \`secretaryReply\` (رد السكرتيرة)، لازم تقراه بالظبط للمريض وتقوله "السكرتيرة بتقولك: كذا كذا".

خليك دايماً ترد باختصار، ومباشر، ودمك خفيف بلهجة مصرية مفهومة وقريبة للقلب.`;

let currentAudioSource: AudioBufferSourceNode | null = null;
let currentTtsReqId = 0;

export function ChatBot({ onClose, onNotify }: { onClose: () => void, onNotify: (m: string, e?: boolean) => void }) {
  const [messages, setMessages] = useState<{type: 'bot'|'user', text: string}[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<any>(null);
  const audioEnabledRef = useRef(true);
  const didInitRef = useRef(false);

  const toggleAudio = () => {
    const newVal = !isAudioEnabled;
    setIsAudioEnabled(newVal);
    audioEnabledRef.current = newVal;
    if (!newVal) {
      currentTtsReqId++;
      if (currentAudioSource) {
        try { currentAudioSource.stop(); } catch(e) {}
        currentAudioSource = null;
      }
      window.speechSynthesis.cancel();
    }
  };

  const speakText = async (text: string) => {
    if (!audioEnabledRef.current) return;
    
    currentTtsReqId++;
    const reqId = currentTtsReqId;
    
    if (currentAudioSource) {
      try { currentAudioSource.stop(); } catch(e) {}
      currentAudioSource = null;
    }
    window.speechSynthesis.cancel();

    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Kore' },
              },
          },
        },
      });
      if (reqId !== currentTtsReqId || !audioEnabledRef.current) return;

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const binaryString = atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const int16Array = new Int16Array(bytes.buffer);
        const float32Array = new Float32Array(int16Array.length);
        for (let i = 0; i < int16Array.length; i++) {
          float32Array[i] = int16Array[i] / 32768.0;
        }
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const buffer = audioCtx.createBuffer(1, float32Array.length, 24000);
        buffer.getChannelData(0).set(float32Array);
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(audioCtx.destination);
        source.start();
        currentAudioSource = source;
      }
    } catch (error) {
      if (reqId !== currentTtsReqId || !audioEnabledRef.current) return;
      console.error("TTS Error:", error);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      window.speechSynthesis.speak(utterance);
    }
  };

  const botSay = (text: string) => {
    setMessages(prev => [...prev, { type: 'bot', text }]);
    speakText(text);
  };

  const userSay = (text: string) => {
    setMessages(prev => [...prev, { type: 'user', text }]);
  };

  useEffect(() => {
    if (didInitRef.current) return;
    didInitRef.current = true;

    chatRef.current = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction,
        tools: [{
          functionDeclarations: [
            {
              name: "check_booking_status",
              description: "Check the status of a patient's booking using their request reference number, phone number, or exact full name.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  referenceNumber: { 
                    type: Type.STRING, 
                    description: "The booking reference number, phone number, or exact name provided by the patient." 
                  }
                },
                required: ["referenceNumber"]
              }
            },
            {
              name: "book_appointment",
              description: "Book a new appointment for a patient and send the request to the secretary.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Patient's full name" },
                  phone: { type: Type.STRING, description: "Patient's phone number" },
                  age: { type: Type.STRING, description: "Patient's age" },
                  address: { type: Type.STRING, description: "Patient's address" },
                  serviceId: {  
                    type: Type.STRING, 
                    description: "The ID of the requested service. MUST be one of: first-only, follow-only, first-ecg, follow-ecg" 
                  },
                  date: { type: Type.STRING, description: "Date of the appointment in YYYY-MM-DD format" },
                  time: { type: Type.STRING, description: "Time of the appointment in HH:MM format" },
                  payment: {
                    type: Type.STRING,
                    description: "Payment method chosen by the patient: cash, visa, wallet, or instapay"
                  }
                },
                required: ["name", "phone", "age", "address", "serviceId", "date", "time", "payment"]
              }
            }
          ]
        }]
      }
    });

    botSay("مرحباً بك في عيادة الدكتور تيمور عبد الحليم.\nكيف يمكنني مساعدتك اليوم؟ يمكنك حجز موعد جديد أو الاستعلام عن حجزك أو طرح أي استفسار طبي.");
    
    return () => {
      if (currentAudioSource) {
        try { currentAudioSource.stop(); } catch(e) {}
      }
      window.speechSynthesis.cancel();
    };
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleInputSubmit = async () => {
    if (!inputValue.trim()) return;
    const val = inputValue.trim();
    setInputValue('');
    userSay(val);

    setIsTyping(true);
    try {
      let response = await chatRef.current.sendMessage({ message: val });
      
      while (response.functionCalls && response.functionCalls.length > 0) {
        const functionResponses = [];
        
        for (const call of response.functionCalls) {
          let toolResult: any = {};

          try {
            if (call.name === "check_booking_status") {
              const rawRef = (call.args as any)?.referenceNumber;
              let rawQuery = rawRef ? String(rawRef).trim() : '';
              
              if (!rawQuery || rawQuery === 'UNDEFINED' || rawQuery === 'NULL') {
                toolResult = { error: "لم يتم تزويد بيانات صالحة. الرجاء سؤال المريض عن رقم الطلب أو التليفون." };
              } else {
                let formattedRef = rawQuery.toUpperCase().replace(/\s+/g, '');
                let finalRef = '';

                if (formattedRef.startsWith('REQ-')) {
                  const snap = await getDoc(doc(db, 'bookings', formattedRef));
                  if (snap.exists()) finalRef = formattedRef;
                }
                
                if (!finalRef) {
                  const snapPos = await getDoc(doc(db, 'bookings', 'REQ-' + formattedRef));
                  if (snapPos.exists()) finalRef = 'REQ-' + formattedRef;
                }

                if (!finalRef) {
                  const safePhone = normalizeSearchKey(rawQuery);
                  if (safePhone) {
                    const idxPhone = await getDoc(doc(db, 'booking_idx_phone', safePhone));
                    if (idxPhone.exists()) finalRef = idxPhone.data().ref;
                  }
                }

                if (!finalRef) {
                  const safeName = normalizeSearchKey(rawQuery);
                  if (safeName) {
                    const idxName = await getDoc(doc(db, 'booking_idx_name', safeName));
                    if (idxName.exists()) finalRef = idxName.data().ref;
                  }
                }

                if (finalRef) {
                  const snap = await getDoc(doc(db, 'bookings', finalRef));
                  if (snap.exists()) {
                    const booking = snap.data() as Booking;
                    toolResult = {
                      found: true,
                      status: booking.status,
                      queueNumber: booking.queue || null,
                      cancelReason: booking.cancelReason || null,
                      secretaryReply: booking.secretaryReply || null,
                      patientName: booking.name,
                      date: booking.date,
                      time: booking.time
                    };
                  } else {
                    toolResult = { found: false, message: "لا يوجد حجز بهذه البيانات." };
                  }
                } else {
                  toolResult = {
                    found: false,
                    message: "لم يتم العثور على أي حجز بهذا الرقم أو الاسم أو التليفون."
                  };
                }
              }
            } else if (call.name === "book_appointment") {
              const args = call.args as any;
              const ref = 'REQ-' + Math.random().toString(36).substr(2, 6).toUpperCase();
              
              const map: Record<string, {name: string, price: number}> = {
                'first-only': {name: 'كشف أول', price: 300},
                'follow-only': {name: 'كشف إعادة', price: 150},
                'first-ecg': {name: 'كشف أول + رسم قلب', price: 350},
                'follow-ecg': {name: 'كشف إعادة + رسم قلب', price: 200}
              };
              
              const svc = map[args.serviceId] || {name: 'غير محدد', price: 0};
              
              const newBooking: Booking = {
                id: Date.now(), ref, name: args.name || 'لم يذكر', phone: args.phone || 'غير محدد', age: args.age || 'غير محدد', address: args.address || 'غير محدد',
                service: args.serviceId || 'first-only', serviceName: svc.name, price: svc.price,
                payment: args.payment || 'cash', date: args.date || new Date().toISOString().split('T')[0], time: args.time || 'غير محدد', status: 'pending',
                cancelReason: '', createdAt: new Date().toISOString(), queue: null, source: 'chat_bot',
                uid: auth.currentUser?.uid || ''
              };
              try {
                await createFirebaseBooking(newBooking);
                toolResult = {
                  success: true,
                  referenceNumber: ref,
                  message: "تم حفظ الطلب بنجاح وهو الآن قيد انتظار مراجعة السكرتيرة."
                };
              } catch (e) {
                console.error(e);
                toolResult = {
                  success: false,
                  message: "فشل الحجز في قاعدة بيانات السكرتيرة. يرجى إبلاغ المريض بالمحاولة لاحقاً."
                };
              }
            }
          } catch (e: any) {
             toolResult = { error: String(e) };
          }

          functionResponses.push({
            functionResponse: {
              id: call.id,
              name: call.name,
              response: toolResult
            }
          });
        }

        response = await chatRef.current.sendMessage({ message: functionResponses });
      }
      
      botSay(response.text || "عذراً، لم أتمكن من فهم ذلك.");
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      botSay(`عذراً، حدث خطأ: ${error?.message || String(error)}`);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center">
      <div className="bg-white rounded-2xl w-[95%] max-w-[450px] h-[80vh] flex flex-col overflow-hidden shadow-[0_10px_40px_rgba(0,0,0,0.2)]">
        <div className="bg-gradient-primary text-white p-4 flex justify-between items-center">
          <span className="font-bold"><i className="fas fa-robot mr-2"></i> المساعد الذكي</span>
          <div className="flex items-center gap-3">
            <button onClick={toggleAudio} className="bg-transparent border-none text-white text-lg cursor-pointer" title={isAudioEnabled ? "إيقاف الصوت" : "تشغيل الصوت"}>
              <i className={`fas ${isAudioEnabled ? 'fa-volume-up' : 'fa-volume-mute'}`}></i>
            </button>
            <button onClick={onClose} className="bg-transparent border-none text-white text-xl cursor-pointer">
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 bg-gray-50 flex flex-col gap-3">
          {messages.map((m, i) => (
            <div key={i} className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed animate-[fadeIn_0.3s_ease] ${
              m.type === 'bot' 
                ? 'bg-white rounded-br-sm self-start shadow-sm whitespace-pre-wrap' 
                : 'bg-primary text-white rounded-bl-sm self-end'
            }`}>
              {m.text}
            </div>
          ))}
          {isTyping && (
            <div className="bg-white rounded-2xl rounded-br-sm self-start shadow-sm p-3 max-w-[80%] flex gap-1 items-center">
              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-3 bg-white border-t border-gray-100">
          <div className="flex flex-col gap-2">
            <input 
              type="text" 
              className="w-full p-2 border border-gray-300 rounded-md font-sans"
              value={inputValue}
              onChange={e => setInputValue(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleInputSubmit()}
              placeholder="اكتب رسالتك أو بيانات الحجز هنا..."
              autoFocus
              disabled={isTyping}
            />
            <div className="flex gap-2">
              <button onClick={handleInputSubmit} disabled={isTyping} className="flex-1 p-2 bg-primary text-white rounded-md font-bold flex items-center justify-center gap-2 disabled:opacity-50">
                إرسال
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
