import React, { useState, useEffect, useRef } from 'react';
import { User, Booking, getBookings, saveBookings, getQueueData, saveQueueData, getCalls, saveCalls, getExceptions, saveExceptions, updateFirebaseBooking, deleteFirebaseBooking, addFirebaseUser, deleteFirebaseUser } from '../store';
import { CancelModal, EditModal, CallModal, ReplyModal } from './Modals';
import { AdminPatients } from './AdminPatients';
import { AdminExpenses } from './AdminExpenses';
import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';

export function AdminPanel({ user, onLogout, onNotify }: { user: User, onLogout: () => void, onNotify: (m: string, e?: boolean) => void }) {
  const [activeTab, setActiveTab] = useState('appts');
  const [bookings, setBookings] = useState<Booking[]>(getBookings());
  const [queueData, setQueueData] = useState(getQueueData());
  const [calls, setCalls] = useState(getCalls());
  const [exceptions, setExceptions] = useState(getExceptions());
  const [users, setUsers] = useState<User[]>([]);

  // Modals state
  const [cancelId, setCancelId] = useState<number | null>(null);
  const [editId, setEditId] = useState<number | null>(null);
  const [replyId, setReplyId] = useState<number | null>(null);
  const [showCallModal, setShowCallModal] = useState(false);

  // Queue manual state
  const [qCurNum, setQCurNum] = useState(queueData.cNum === '-' ? '' : queueData.cNum);
  const [qCurName, setQCurName] = useState(queueData.cName === '-' ? '' : queueData.cName);
  const [qNextNum, setQNextNum] = useState(queueData.nNum === '-' ? '' : queueData.nNum);
  const [qNextName, setQNextName] = useState(queueData.nName === '-' ? '' : queueData.nName);

  // Logs state
  const [logSearch, setLogSearch] = useState('');
  
  // Date filter state
  const [filterDate, setFilterDate] = useState('');
  const [apptSearch, setApptSearch] = useState('');

  // Hours state
  const [hDate, setHDate] = useState('');
  const [hType, setHType] = useState('normal');
  const [hStart, setHStart] = useState('17:00');
  const [hEnd, setHEnd] = useState('23:00');

  // Users state
  const [uName, setUName] = useState('');
  const [uEmail, setUEmail] = useState('');
  const [uRole, setURole] = useState<'doctor' | 'secretary'>('secretary');
  const [newDocEmail, setNewDocEmail] = useState('');

  const isFirstLoad = useRef(true);

  useEffect(() => {
    // إعداد مراقب حي لطلبات Firebase
    const unsub = onSnapshot(collection(db, 'bookings'), (snap) => {
      const changes = snap.docChanges();
      
      if (!isFirstLoad.current) {
        const hasNewPending = changes.some(c => c.type === 'added' && c.doc.data().status === 'pending');
        if (hasNewPending) {
          onNotify('🔔 إشعار: وصلك طلب حجز جديد للتو!', false);
          try {
            const au = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');
            au.play().catch(() => {});
          } catch(e) {}
        }
      }
      isFirstLoad.current = false;

      const bks: Booking[] = snap.docs.map(d => d.data() as Booking);
      
      const todayStr = new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0') + '-' + String(new Date().getDate()).padStart(2, '0');
      const normalizeDate = (dStr: string) => {
        if (!dStr) return '';
        if (dStr === 'اليوم' || dStr === 'النهاردة' || dStr === 'النهارده') return todayStr;
        const parts = dStr.split(/[-/]/);
        if (parts.length === 3) {
           if (parts[2].length === 4) return `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
           if (parts[0].length === 4) return `${parts[0]}-${parts[1].padStart(2,'0')}-${parts[2].padStart(2,'0')}`;
        }
        return dStr;
      };
      
      // Auto-cancel past pending bookings
      bks.forEach(b => {
        if (b.status === 'pending') {
          const bDate = normalizeDate(b.date);
          if (bDate && bDate < todayStr) {
            updateFirebaseBooking(b.ref, { 
              status: 'cancelled', 
              cancelReason: 'إلغاء تلقائي لانتهاء موعد الكشف' 
            }).catch(console.error);
          }
        }
      });
      
      setBookings(bks);
    }, (err) => {
      console.error("Firebase Snapshot Error:", err);
      // Fallback to local storage if reading fails
      setBookings(getBookings());
    });
    
    let unsubUsers = () => {};
    if (user.role === 'doctor') {
      unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
         setUsers(snap.docs.map(d => ({ email: d.id, ...d.data() } as User)));
      });
    }

    setQueueData(getQueueData());
    return () => { unsub(); unsubUsers(); };
  }, [activeTab]);

  const confirmAppt = async (id: number) => {
    const b = bookings.find(x => x.id === id);
    if (b && b.status === 'pending') {
      const dayConfirmed = bookings.filter(x => x.date === b.date && x.status === 'confirmed' && x.queue);
      const nextQ = dayConfirmed.length + 1;
      if (nextQ > 30) { onNotify('⛔ اكتمل عدد الأدوار لهذا اليوم (30)', true); return; }
      
      await updateFirebaseBooking(b.ref, { status: 'confirmed', queue: nextQ });
      onNotify('✅ تم التأكيد - رقم الدور: ' + nextQ);
    }
  };

  const deleteAppt = async (id: number) => {
    const b = bookings.find(x => x.id === id);
    if (b) await deleteFirebaseBooking(b.ref);
    onNotify('تم الحذف الدائم');
  };

  const handleCancel = async (reason: string) => {
    if (cancelId) {
      const b = bookings.find(x => x.id === cancelId);
      if (b) {
        await updateFirebaseBooking(b.ref, { status: 'cancelled', cancelReason: reason });
        setCancelId(null); 
        onNotify('تم الإلغاء');
      }
    }
  };

  const handleEdit = async (newService: string) => {
    if (editId) {
      const S: Record<string, number> = {'first-only':300,'first-ecg':350,'follow-only':150,'follow-ecg':200};
      const N: Record<string, string> = {'first-only':'كشف أول','first-ecg':'كشف أول + رسم قلب','follow-only':'كشف إعادة','follow-ecg':'كشف إعادة + رسم قلب'};
      const b = bookings.find(x => x.id === editId);
      if (b) {
        await updateFirebaseBooking(b.ref, { service: newService, serviceName: N[newService], price: S[newService] });
        setEditId(null); 
        onNotify('تم التعديل');
      }
    }
  };

  const handleReply = async (reply: string) => {
    if (replyId) {
      const b = bookings.find(x => x.id === replyId);
      if (b) {
        await updateFirebaseBooking(b.ref, { secretaryReply: reply });
        setReplyId(null); 
        onNotify('تم إضافة الرد بنجاح');
      }
    }
  };

  const handleSaveCall = (name: string, phone: string, notes: string) => {
    const newCalls = [...calls, { name, phone, notes, time: new Date().toISOString() }];
    saveCalls(newCalls); setCalls(newCalls);
    setShowCallModal(false); onNotify('تم التسجيل');
  };

  const saveManualQueue = () => {
    const data = {
      cNum: qCurNum || '-', cName: qCurName || '-',
      nNum: qNextNum || '-', nName: qNextName || '-'
    };
    saveQueueData(data); setQueueData(data);
    onNotify('✅ تم تحديث شاشة الانتظار');
  };

  const resetManualQueue = () => {
    const data = { cNum: '-', cName: '-', nNum: '-', nName: '-' };
    saveQueueData(data); setQueueData(data);
    setQCurNum(''); setQCurName(''); setQNextNum(''); setQNextName('');
    onNotify('🔄 تم إعادة التعيين');
  };

  const handleSaveHours = () => {
    if (!hDate) { onNotify('اختر التاريخ', true); return; }
    const ex = { ...exceptions };
    ex[hDate] = { status: hType, start: hStart, end: hEnd };
    saveExceptions(ex); setExceptions(ex);
    onNotify('تم حفظ التعديل');
  };

  const deleteHour = (d: string) => {
    const ex = { ...exceptions };
    delete ex[d];
    saveExceptions(ex); setExceptions(ex);
    onNotify('تم الحذف');
  };

  const handleAddUser = async () => {
    if (!uName || !uEmail) { onNotify('أكمل البيانات', true); return; }
    const emailLower = uEmail.trim().toLowerCase();
    if (users.find(x => x.email === emailLower)) { onNotify('الإيميل مستخدم مسبقاً', true); return; }
    
    await addFirebaseUser(emailLower, { name: uName, email: emailLower, role: uRole });
    setUName(''); setUEmail('');
    onNotify('تمت إضافة المستخدم بنجاح');
  };

  const handleChangeMyEmail = async () => {
    if (!newDocEmail) { onNotify('أدخل الإيميل الجديد', true); return; }
    const newEmailLower = newDocEmail.trim().toLowerCase();
    
    if (newEmailLower === user.email.toLowerCase()) {
       onNotify('هذا هو إيميلك الحالي!', true); return;
    }
    
    await addFirebaseUser(newEmailLower, { name: user.name, email: newEmailLower, role: 'doctor' });
    await deleteFirebaseUser(user.email);
    onNotify('تم نقل الصلاحية بنجاح! جاري تسجيل الخروج...');
    setTimeout(() => onLogout(), 2500);
  };

  const deleteUser = async (email: string) => {
    setUsers(prev => prev.filter(u => u.email !== email));
    await deleteFirebaseUser(email);
    onNotify('تم الحذف والسحب بنجاح');
  };

  const normalizeDate = (dStr: string) => {
    if (!dStr) return '';
    if (dStr === 'اليوم' || dStr === 'النهاردة' || dStr === 'النهارده') {
       const t = new Date();
       return t.getFullYear() + '-' + String(t.getMonth()+1).padStart(2,'0') + '-' + String(t.getDate()).padStart(2,'0');
    }
    const parts = dStr.split(/[-/]/);
    if (parts.length === 3) {
       if (parts[2].length === 4) return `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
       if (parts[0].length === 4) return `${parts[0]}-${parts[1].padStart(2,'0')}-${parts[2].padStart(2,'0')}`;
    }
    return dStr;
  };

  const displayBookings = bookings.filter(b => {
    const today = new Date();
    const todayStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
    if (normalizeDate(b.date) < todayStr) return false;

    const dMatch = filterDate ? normalizeDate(b.date) === filterDate : true;
    const q = apptSearch.toLowerCase().trim();
    const sMatch = q ? (b.name.toLowerCase().includes(q) || b.phone.includes(q) || b.ref.toLowerCase().includes(q)) : true;
    return dMatch && sMatch;
  });

  const renderAppts = () => {
    if (!displayBookings.length) return <p className="text-center text-gray-500 py-4">لا توجد طلبات {filterDate ? `بتاريخ ${filterDate}` : ''} {apptSearch ? `للبحث: ${apptSearch}` : ''}</p>;
    return [...displayBookings].reverse().map(b => (
      <div key={b.id} className={`bg-white p-2.5 rounded-lg mb-1.5 border-r-4 ${b.status === 'pending' ? 'border-[#f39c12]' : b.status === 'confirmed' ? 'border-[#2ecc71]' : 'border-[#e74c3c] opacity-85'}`}>
        <div className="flex justify-between mb-1">
          <strong>
            {b.source === 'chat_bot' && <span className="mr-1 text-sm text-blue-500" title="قادم من البوت الذكي">🤖</span>} 
            {b.name} <span className="text-gray-500 text-xs font-normal">({b.age ? b.age + ' سنة' : '-'})</span> 
            {b.queue ? <span className="bg-primary text-white px-1.5 py-0.5 rounded text-xs ml-1">🎫 {b.queue}</span> : <span className="bg-[#f39c12] text-white px-1.5 py-0.5 rounded text-xs ml-1">⏳ بانتظار</span>}
          </strong>
          <span className="text-gray-500 text-xs">{b.ref}</span>
        </div>
        <div className="text-sm text-gray-600 mb-1">
          <div>📞 <span dir="ltr">{b.phone}</span> {b.address ? `| 📍 ${b.address}` : ''}</div>
          <div>{b.serviceName} | الدفع: {{'cash': 'كاش', 'visa': 'فيزا', 'wallet': 'محفظة', 'instapay': 'إنستاباي'}[b.payment || 'cash']} | {b.date} {b.time}</div>
        </div>
        <div className="flex gap-1 flex-wrap mt-2">
          {b.status === 'pending' && (
            <>
              <button className="bg-[#2ecc71] text-white px-2 py-1 rounded border-none text-xs font-bold cursor-pointer" onClick={() => confirmAppt(b.id)}>✅ تأكيد + دور</button>
              <button className="bg-[#e74c3c] text-white px-2 py-1 rounded border-none text-xs font-bold cursor-pointer" onClick={() => setCancelId(b.id)}>❌ إلغاء</button>
            </>
          )}
          {b.status === 'confirmed' && (
            <button className="bg-[#f39c12] text-white px-2 py-1 rounded border-none text-xs font-bold cursor-pointer" onClick={() => setEditId(b.id)}>✏️ تعديل</button>
          )}
          <button className="bg-primary text-white px-2 py-1 rounded border-none text-xs font-bold cursor-pointer" onClick={() => setReplyId(b.id)}>💬 إضافة رد</button>
          <button className="bg-gray-400 text-white px-2 py-1 rounded border-none text-xs font-bold cursor-pointer" onClick={() => deleteAppt(b.id)}>🗑️ حذف</button>
        </div>
        {b.secretaryReply && (
          <div className="mt-2 p-2 bg-blue-50 text-primary text-xs rounded border border-blue-100">
            <strong>رد السكرتيرة:</strong> {b.secretaryReply}
          </div>
        )}
      </div>
    ));
  };

  const renderLogs = () => {
    const q = logSearch.toLowerCase().trim();
    let sd = q;
    if (['اليوم', 'النهاردة', 'النهارده'].includes(q)) {
      const d = new Date();
      sd = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }
    
    const f = bookings.filter(b => {
      if (b.status !== 'confirmed') return false;
      return b.name.toLowerCase().includes(q) || 
      b.phone.includes(q) || 
      (b.address && b.address.toLowerCase().includes(q)) ||
      (b.date && normalizeDate(b.date).includes(sd)) ||
      (b.ref && b.ref.toLowerCase().includes(q));
    });
    if (!f.length) return <p className="text-center text-gray-500">لا توجد نتائج</p>;
    return [...f].reverse().map(b => (
      <div key={b.id} className="bg-white p-2 rounded-md mb-1 text-sm">
        <div className="flex justify-between">
          <strong>
            {b.source === 'chat_bot' && <span className="mr-1 text-sm text-blue-500" title="قادم من البوت الذكي">🤖</span>} 
            {b.name} {b.queue ? `| 🎫 ${b.queue}` : '| ⏳'}
          </strong>
          <span className="text-gray-400 text-xs">{new Date(b.createdAt).toLocaleString('ar-EG')}</span>
        </div>
        <div className="mt-1 flex justify-between items-center text-xs text-gray-500">
           <span>📞 <span dir="ltr">{b.phone}</span></span>
           <span>{b.address ? `📍 ${b.address}` : ''}</span>
        </div>
        <div className="mt-1 border-t border-gray-100 pt-1">
          {b.serviceName} | <span className={b.status === 'cancelled' ? 'text-red-500' : 'text-green-500'}>{b.status === 'cancelled' ? '❌ ملغي' : '✅ ' + (b.status === 'confirmed' ? 'مؤكد' : 'انتظار')}</span>
        </div>
      </div>
    ));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-gradient-primary text-white p-3 flex justify-between items-center flex-wrap gap-2">
        <span className="font-extrabold"><i className="fas fa-clinic-medical"></i> لوحة الإدارة</span>
        <div className="flex items-center gap-2">
          <span>{user.name} ({user.role === 'doctor' ? 'الدكتور' : 'السكرتيرة'})</span>
          <button className="bg-white/20 text-white border-none px-3 py-1.5 rounded-full font-bold text-xs cursor-pointer" onClick={onLogout}>خروج</button>
        </div>
      </div>

      <div className="p-4 max-w-5xl mx-auto">
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-white p-2.5 rounded-lg text-center"><div className="text-xs">الإجمالي</div><div className="text-xl font-black">{displayBookings.length}</div></div>
          <div className="bg-white p-2.5 rounded-lg text-center"><div className="text-xs">انتظار</div><div className="text-xl font-black text-[#f39c12]">{displayBookings.filter(x => x.status === 'pending').length}</div></div>
          <div className="bg-white p-2.5 rounded-lg text-center"><div className="text-xs">مؤكد</div><div className="text-xl font-black text-[#2ecc71]">{displayBookings.filter(x => x.status === 'confirmed').length}</div></div>
        </div>

        <div className="flex gap-1.5 mb-2.5 flex-wrap">
          {[
            { id: 'appts', label: '📋 الطلبات' },
            { id: 'queueMgmt', label: '🎫 إدارة الدور' },
            { id: 'logs', label: '📁 سجل الحجوزات' },
            { id: 'calls', label: '📞 المكالمات' },
            { id: 'hours', label: '🕒 إدارة المواعيد' },
            { id: 'expenses', label: '💸 المصروفات' },
            ...(user.role === 'doctor' ? [
              { id: 'patients', label: '⚕️ المرضى' },
              { id: 'rev', label: '💰 إيراد اليوم' },
              { id: 'emails', label: '📧 إدارة الإيميلات والصلاحيات' }
            ] : [])
          ].map(t => (
            <div key={t.id} onClick={() => setActiveTab(t.id)} className={`px-3 py-1.5 bg-white rounded-md cursor-pointer text-xs font-bold border flex items-center gap-1 ${activeTab === t.id ? 'bg-primary text-white border-primary' : 'border-gray-300'}`}>
              {t.label}
            </div>
          ))}
        </div>

        <div>
          {activeTab === 'appts' && (
            <div>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3 gap-2 bg-white p-3 rounded-lg shadow-sm border border-gray-100">
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-gray-700 whitespace-nowrap">التاريخ:</span>
                    <input type="date" className="w-full sm:w-auto p-1.5 border border-gray-300 rounded-md font-sans text-sm outline-none focus:border-primary" value={filterDate} onChange={e => setFilterDate(e.target.value)} />
                    {filterDate && <button className="bg-gray-100 text-gray-600 px-3 py-1.5 rounded-md border-none font-bold text-xs cursor-pointer hover:bg-gray-200 transition-colors" onClick={() => setFilterDate('')}>الكل</button>}
                    <button className="bg-blue-50 text-primary px-3 py-1.5 rounded-md border-none font-bold text-xs cursor-pointer hover:bg-blue-100 transition-colors" onClick={() => {
                      const d = new Date();
                      setFilterDate(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
                    }}>اليوم</button>
                  </div>
                  
                  <div className="flex items-center gap-2 flex-1 w-full sm:w-auto">
                    <span className="text-sm font-bold text-gray-700 whitespace-nowrap">البحث:</span>
                    <input type="text" className="w-full p-1.5 border border-gray-300 rounded-md font-sans text-sm outline-none focus:border-primary flex-1" placeholder="رقم الطلب، الاسم، التليفون..." value={apptSearch} onChange={e => setApptSearch(e.target.value)} />
                  </div>
                </div>
                
                <button className="bg-primary text-white border-none px-4 py-2 rounded-md font-bold text-xs cursor-pointer hover:bg-primary-dark transition-colors whitespace-nowrap w-full sm:w-auto mt-2 sm:mt-0" onClick={() => setShowCallModal(true)}>تسجيل مكالمة</button>
              </div>
              {renderAppts()}
            </div>
          )}

          {activeTab === 'queueMgmt' && (
            <div className="bg-white p-4 rounded-xl mb-2.5">
              <h4 className="mb-4 font-bold">🎫 التحكم اليدوي في شاشة الانتظار</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className="block text-sm mb-1">رقم الدور الحالي</label><input type="number" className="w-full p-2 border border-gray-300 rounded-md font-sans" value={qCurNum} onChange={e => setQCurNum(e.target.value)} placeholder="مثال: 5" /></div>
                <div><label className="block text-sm mb-1">اسم المريض الحالي</label><input type="text" className="w-full p-2 border border-gray-300 rounded-md font-sans" value={qCurName} onChange={e => setQCurName(e.target.value)} placeholder="مثال: أحمد محمد" /></div>
                <div><label className="block text-sm mb-1">رقم الدور القادم</label><input type="number" className="w-full p-2 border border-gray-300 rounded-md font-sans" value={qNextNum} onChange={e => setQNextNum(e.target.value)} placeholder="مثال: 6" /></div>
                <div><label className="block text-sm mb-1">اسم المريض القادم</label><input type="text" className="w-full p-2 border border-gray-300 rounded-md font-sans" value={qNextName} onChange={e => setQNextName(e.target.value)} placeholder="مثال: علي حسن" /></div>
              </div>
              <div className="flex gap-2 mt-4">
                <button className="bg-[#2ecc71] text-white border-none px-4 py-2 rounded-md font-bold cursor-pointer" onClick={saveManualQueue}>💾 حفظ وتحديث الشاشة</button>
                <button className="bg-gray-200 text-gray-800 border-none px-4 py-2 rounded-md font-bold cursor-pointer" onClick={resetManualQueue}>🔄 إعادة تعيين</button>
              </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div>
              <input type="text" className="w-full p-2 border border-gray-300 rounded-md font-sans mb-2.5" placeholder="بحث..." value={logSearch} onChange={e => setLogSearch(e.target.value)} />
              {renderLogs()}
            </div>
          )}

          {activeTab === 'calls' && (
            <div>
              {!calls.length ? <p className="text-center text-gray-500">لا مكالمات</p> : [...calls].reverse().map((c, i) => (
                <div key={i} className="bg-white p-2 rounded-md mb-1 text-sm">
                  <strong>📞 {c.name}</strong> - <span dir="ltr">{c.phone}</span> - {c.notes || 'بدون ملاحظات'}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'rev' && user.role === 'doctor' && (
            <div className="bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364] text-white p-4 rounded-xl">
              <div className="text-2xl font-black mb-2">💰 إجمالي اليوم: {bookings.filter(b => b.status === 'confirmed' && b.date === new Date().toISOString().split('T')[0]).reduce((sum, b) => sum + (b.price || 0), 0)} جنيه</div>
              <div className="opacity-80">عدد الحجوزات المؤكدة: {bookings.filter(b => b.status === 'confirmed' && b.date === new Date().toISOString().split('T')[0]).length}</div>
            </div>
          )}

          {activeTab === 'hours' && (
            <div>
              <div className="bg-white p-2.5 rounded-lg mb-2.5">
                <h4 className="font-bold mb-1.5">📅 تعديل مواعيد يوم محدد</h4>
                <div className="flex gap-1.5 flex-wrap">
                  <input type="date" className="flex-1 p-2 border border-gray-300 rounded-md font-sans" value={hDate} onChange={e => setHDate(e.target.value)} />
                  <select className="flex-1 p-2 border border-gray-300 rounded-md font-sans" value={hType} onChange={e => setHType(e.target.value)}>
                    <option value="normal">المواعيد العادية (5م - 11م)</option>
                    <option value="custom">مواعيد مخصصة</option>
                    <option value="closed">إغلاق اليوم (عطلة)</option>
                  </select>
                  {hType === 'custom' && (
                    <div className="w-full flex gap-1.5">
                      <input type="time" className="flex-1 p-2 border border-gray-300 rounded-md font-sans" value={hStart} onChange={e => setHStart(e.target.value)} />
                      <input type="time" className="flex-1 p-2 border border-gray-300 rounded-md font-sans" value={hEnd} onChange={e => setHEnd(e.target.value)} />
                    </div>
                  )}
                  <button className="bg-primary text-white border-none px-4 py-2 rounded-md font-bold cursor-pointer" onClick={handleSaveHours}>حفظ</button>
                </div>
              </div>
              <div>
                {Object.keys(exceptions).length === 0 ? <p className="text-center text-gray-500">لا توجد مواعيد استثنائية</p> : Object.entries(exceptions).map(([date, ex]: [string, any]) => (
                  <div key={date} className="flex justify-between items-center bg-white p-2 rounded-md mb-1 text-sm">
                    <span>{date}</span>
                    <span>{ex.status === 'closed' ? '❌ مغلق' : `🕒 ${ex.start} - ${ex.end}`}</span>
                    <button className="bg-gray-400 text-white px-2 py-1 rounded border-none text-xs font-bold cursor-pointer" onClick={() => deleteHour(date)}>حذف</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'emails' && user.role === 'doctor' && (
            <div>
              <div className="bg-white p-3 rounded-lg mb-4 border border-blue-200 shadow-sm">
                <h4 className="font-bold mb-2 text-primary">🔄 نقل صلاحيتك (طبيب) لحساب جوجل آخر</h4>
                <p className="text-xs text-gray-600 mb-3">سيتم سحب الإدارة العليا من حسابك الحالي ونقلها فوراً للحساب الجديد الذي ستكتبه هنا، وسيتم خروجك لتتمكن من الدخول للحساب الجديد.</p>
                <div className="flex gap-2 flex-wrap">
                  <input type="email" className="flex-1 p-2 border border-gray-300 rounded-md font-sans text-left min-w-[200px]" dir="ltr" placeholder="إيميل جوجل (gmail) الجديد..." value={newDocEmail} onChange={e => setNewDocEmail(e.target.value)} />
                  <button className="bg-primary text-white border-none px-4 py-2 rounded-md font-bold cursor-pointer hover:bg-primary-dark transition-colors" onClick={handleChangeMyEmail}>نقل الحساب الأساسي</button>
                </div>
              </div>

              <div className="bg-white p-2.5 rounded-lg mb-2.5 shadow-sm">
                <h4 className="font-bold mb-2">➕ إضافة مستخدم جديد (طبيب مساعد أو سكرتيرة)</h4>
                <div className="flex gap-1.5 flex-wrap">
                  <input type="text" className="flex-1 p-2 border border-gray-300 rounded-md font-sans min-w-[100px]" placeholder="الاسم" value={uName} onChange={e => setUName(e.target.value)} />
                  <input type="email" className="flex-[1.5] p-2 border border-gray-300 rounded-md font-sans text-left min-w-[150px]" dir="ltr" placeholder="إيميل جوجل (gmail)" value={uEmail} onChange={e => setUEmail(e.target.value)} />
                  <select className="flex-[0.8] p-2 border border-gray-300 rounded-md font-sans min-w-[100px]" value={uRole} onChange={e => setURole(e.target.value as 'doctor'|'secretary')}>
                    <option value="secretary">السكرتيرة</option><option value="doctor">طبيب / مدير</option>
                  </select>
                  <button className="bg-[#2ecc71] hover:bg-green-600 text-white border-none px-4 py-2 rounded-md font-bold cursor-pointer transition-colors" onClick={handleAddUser}>إضافة صلاحية</button>
                </div>
              </div>

              <div className="mt-4">
                <h4 className="font-bold mb-2">قائمة الحسابات المصرح لها</h4>
                {users.map((u, i) => (
                  <div key={i} className={`flex justify-between items-center py-2 border-b border-gray-100 text-sm px-3 mb-1 rounded-lg ${user.email === u.email ? 'bg-blue-50 border border-blue-100' : 'bg-white shadow-sm'}`}>
                    <div>
                      <strong>{u.name}</strong> <span className={`px-1.5 py-0.5 rounded text-xs ml-1 ${u.role === 'doctor' ? 'bg-primary text-white' : 'bg-pink-100 text-accent'}`}>{u.role === 'doctor' ? 'طبيب' : 'سكرتيرة'}</span><br/>
                      <span className="text-gray-500 text-xs">{u.email}</span>
                    </div>
                    {user.email === u.email ? (
                      <span className="text-xs text-primary font-bold px-2">حسابك الحالي</span>
                    ) : (
                      <button className="bg-gray-400 text-white px-3 py-1.5 rounded-md border-none text-xs font-bold cursor-pointer hover:bg-red-500 transition-colors" onClick={() => deleteUser(u.email)}>سحب الصلاحية 🗑️</button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'patients' && user.role === 'doctor' && (
            <AdminPatients onNotify={onNotify} />
          )}

          {activeTab === 'expenses' && (
            <AdminExpenses onNotify={onNotify} user={user} />
          )}
        </div>
      </div>

      {cancelId && <CancelModal onClose={() => setCancelId(null)} onConfirm={handleCancel} />}
      {editId && <EditModal service={bookings.find(x => x.id === editId)?.service || 'first-only'} onClose={() => setEditId(null)} onConfirm={handleEdit} />}
      {replyId && <ReplyModal onClose={() => setReplyId(null)} onConfirm={handleReply} />}
      {showCallModal && <CallModal onClose={() => setShowCallModal(false)} onSave={handleSaveCall} />}
    </div>
  );
}
