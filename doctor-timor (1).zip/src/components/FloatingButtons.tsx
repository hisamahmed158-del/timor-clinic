import React from 'react';

export function FloatingButtons({ onOpenQueue, onOpenChat, onOpenBookingChoice }: { onOpenQueue: () => void, onOpenChat: () => void, onOpenBookingChoice: () => void }) {
  return (
    <>
      {/* Booking Button */}
      <button onClick={onOpenBookingChoice} className="fixed bottom-5 right-5 w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-lg z-[999] text-white cursor-pointer border-none animate-wp bg-primary hover:text-white hover:-translate-y-1 transition-transform" title="حجز موعد">
        <i className="fas fa-calendar-check"></i>
      </button>

      {/* ChatBot Button (Purple) */}
      <button onClick={onOpenChat} className="fixed bottom-[85px] right-5 w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-lg z-[999] text-white cursor-pointer border-none animate-wp bg-[#9b59b6] hover:text-white hover:-translate-y-1 transition-transform" title="المساعد الذكي">
        <i className="fas fa-robot"></i>
      </button>
      
      {/* WhatsApp Button */}
      <a href="https://wa.me/201006508388?text=اريد%20حجز%20موعد" target="_blank" rel="noreferrer" className="fixed bottom-5 left-5 w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-lg z-[999] text-white cursor-pointer border-none animate-wp bg-[#25d366] hover:text-white hover:-translate-y-1 transition-transform" title="مراسلة واتساب">
        <i className="fab fa-whatsapp"></i>
      </a>
      
      {/* Queue Screen Button */}
      <button onClick={onOpenQueue} className="fixed bottom-5 left-[85px] w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-lg z-[999] text-white cursor-pointer border-none animate-wp bg-[#6c5ce7] hover:text-white hover:-translate-y-1 transition-transform" title="شاشة الانتظار">
        <i className="fas fa-tv"></i>
      </button>
    </>
  );
}
