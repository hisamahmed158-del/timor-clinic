import React, { useState, useEffect } from 'react';
import { Booking, getExceptions, createFirebaseBooking, normalizeSearchKey } from '../store';
import { db } from '../firebase';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';

export function BookingSection({ onNotify }: { onNotify: (m: string, e?: boolean) => void }) {
  const [tab, setTab] = useState<'book' | 'inq'>('book');
  const [step, setStep] = useState(1);
  const [service, setService] = useState<{id: string, price: number, name: string} | null>(null);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [patient, setPatient] = useState({ name: '', phone: '', age: '', address: '' });
  const [payment, setPayment] = useState('cash');
  const [successRef, setSuccessRef] = useState('');
  const [timeSlots, setTimeSlots] = useState<string[]>([]);
  const [exceptions, setExceptions] = useState(getExceptions());
  const [isClosed, setIsClosed] = useState(false);

  const [inqRef, setInqRef] = useState('');
  const [inqResult, setInqResult] = useState<Booking | null | 'not_found'>(null);
  const [isLoading, setIsLoading] = useState(false);
  const formRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => { setExceptions(getExceptions()); }, []);

  const scrollToForm = () => {
    if (formRef.current) {
      setTimeout(() => formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }
  };

  const updateTimes = (selectedDate: string) => {
    if (!selectedDate) return;
    const ex = exceptions[selectedDate];
    if (ex && ex.status === 'closed') {
      setIsClosed(true); setTimeSlots([]); return;
    }
    setIsClosed(false);
    const start = ex?.start ? parseInt(ex.start.split(':')[0]) : 17;
    const end = ex?.end ? parseInt(ex.end.split(':')[0]) : 23;
    const slots = [];
    for (let h = start; h < end; h++) {
      for (let m = 0; m < 60; m += 30) {
        slots.push(`${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`);
      }
    }
    setTimeSlots(slots); setTime('');
  };

  const handleNext = (nextStep: number) => {
    if (nextStep === 2 && !service) { onNotify('يرجى اختيار الخدمة أولاً', true); return; }
    if (nextStep === 3) {
      if (!date) { onNotify('اختر التاريخ', true); return; }
      if (!time) { onNotify('اختر الوقت', true); return; }
    }
    if (nextStep === 4) {
      if (!patient.name.trim()) { onNotify('أدخل الاسم', true); return; }
      if (!patient.phone.trim()) { onNotify('أدخل الهاتف', true); return; }
    }
    setStep(nextStep);
    scrollToForm();
  };

  const handleSubmit = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      const ref = 'REQ-' + Math.random().toString(36).substr(2, 6).toUpperCase();
      const newBooking: Booking = {
        id: Date.now(), ref, name: patient.name, phone: patient.phone, age: patient.age, address: patient.address,
        service: service!.id, serviceName: service!.name, price: service!.price,
        payment, date, time, status: 'pending', cancelReason: '',
        createdAt: new Date().toISOString(), queue: null
      };
      await createFirebaseBooking(newBooking);
      setSuccessRef(ref);
      onNotify('تم إرسال الطلب');
      scrollToForm();
    } catch (error: any) {
      onNotify(error.message || 'حدث خطأ، يرجى المحاولة مرة أخرى', true);
    } finally {
      setIsLoading(false);
    }
  };

  const clearForm = () => {
    setStep(1); setService(null); setDate(''); setTime('');
    setPatient({ name: '', phone: '', age: '', address: '' }); setSuccessRef('');
  };

  const handleInquiry = async () => {
    let rawQuery = inqRef.trim();
    if (!rawQuery) { onNotify('أدخل رقم الطلب أو التليفون أو الاسم', true); return; }
    
    if (isLoading) return;
    setIsLoading(true);
    setInqResult(null);

    try {
      let formattedRef = rawQuery.toUpperCase().replace(/\s+/g, '');
      
      // 1. Try strict REQ- ID
      if (formattedRef.startsWith('REQ-')) {
        const snap = await getDoc(doc(db, 'bookings', formattedRef));
        if (snap.exists()) {
          setInqResult(snap.data() as Booking);
          return;
        }
      }
      
      // 2. Try assuming it's a generated ID without REQ-
      const snapPossible = await getDoc(doc(db, 'bookings', 'REQ-' + formattedRef));
      if (snapPossible.exists()) {
        setInqResult(snapPossible.data() as Booking);
        return;
      }
      
      // 3. Try searching by phone via index
      const safePhone = normalizeSearchKey(rawQuery);
      if (safePhone) {
        const phoneIdxSnap = await getDoc(doc(db, 'booking_idx_phone', safePhone));
        if (phoneIdxSnap.exists()) {
          const bkRef = phoneIdxSnap.data().ref;
          const bkSnap = await getDoc(doc(db, 'bookings', bkRef));
          if (bkSnap.exists()) {
            setInqResult(bkSnap.data() as Booking);
            return;
          }
        }
      }
      
      // 4. Try searching by precise name via index
      const safeName = normalizeSearchKey(rawQuery);
      if (safeName) {
        const nameIdxSnap = await getDoc(doc(db, 'booking_idx_name', safeName));
        if (nameIdxSnap.exists()) {
          const bkRef = nameIdxSnap.data().ref;
          const bkSnap = await getDoc(doc(db, 'bookings', bkRef));
          if (bkSnap.exists()) {
            setInqResult(bkSnap.data() as Booking);
            return;
          }
        }
      }
      
      setInqResult('not_found');
    } catch (error) {
      console.error(error);
      setInqResult('not_found');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="booking" className="p-8 max-w-6xl mx-auto" ref={formRef}>
      <div className="text-center font-black text-2xl mb-5 text-[#1a1a2e]">خدمات المرضى</div>
      <div className="flex justify-center gap-1.5 mb-4 flex-wrap">
        <div className={`px-4 py-2 bg-white border-2 rounded-full cursor-pointer font-semibold select-none ${tab === 'book' ? 'bg-primary text-white border-primary' : 'border-gray-200'}`} onClick={() => setTab('book')}>📝 حجز جديد</div>
        <div className={`px-4 py-2 bg-white border-2 rounded-full cursor-pointer font-semibold select-none ${tab === 'inq' ? 'bg-primary text-white border-primary' : 'border-gray-200'}`} onClick={() => setTab('inq')}>🔍 استعلام</div>
      </div>

      {tab === 'book' && (
        <div className="bg-white rounded-xl p-5 shadow-sm">
          {!successRef ? (
            <div>
              {step === 1 && (
                <div>
                  <h4 className="font-extrabold mb-2.5">اختر نوع الخدمة</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 my-2.5">
                    {[
                      { id: 'first-only', price: 300, name: 'كشف أول' },
                      { id: 'follow-only', price: 150, name: 'كشف إعادة' },
                      { id: 'first-ecg', price: 350, name: 'كشف أول + رسم قلب' },
                      { id: 'follow-ecg', price: 200, name: 'كشف إعادة + رسم قلب' }
                    ].map(s => (
                      <div key={s.id} onClick={() => { setService(s); onNotify('تم اختيار: ' + s.name); }} className={`bg-gray-50 border-2 rounded-lg p-2.5 text-center cursor-pointer transition-colors select-none hover:border-primary ${service?.id === s.id ? 'border-primary bg-blue-50' : 'border-gray-200'}`}>
                        <h4 className="font-bold">{s.name}</h4><div className="text-xl font-black text-primary my-1">{s.price} ج</div>
                      </div>
                    ))}
                  </div>
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-primary text-white mt-1 flex items-center justify-center gap-1 hover:bg-primary-dark transition-colors" onClick={() => handleNext(2)}>التالي <i className="fas fa-arrow-left"></i></button>
                </div>
              )}
              {step === 2 && (
                <div>
                  <h4 className="font-extrabold mb-2.5">اختر الموعد</h4>
                  <label className="block mb-1 font-semibold">التاريخ</label>
                  <input type="date" className="w-full p-2 border border-gray-300 rounded-md mb-2 font-sans" value={date} onChange={e => { setDate(e.target.value); updateTimes(e.target.value); }} />
                  <label className="block mb-1 font-semibold mt-2">الوقت</label>
                  {isClosed ? (
                    <div className="text-center text-accent font-bold p-2.5">⛔ العيادة مغلقة</div>
                  ) : (
                    <div className="grid grid-cols-4 gap-1.5 mb-2.5">
                      {timeSlots.map(t => (
                        <div key={t} onClick={() => setTime(t)} className={`p-1.5 text-center cursor-pointer text-sm rounded-md border transition-colors ${time === t ? 'bg-primary text-white border-primary' : 'bg-gray-50 border-gray-200 hover:border-primary'}`}>{t}</div>
                      ))}
                    </div>
                  )}
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 mt-1 hover:bg-gray-300 transition-colors" onClick={() => setStep(1)}>رجوع</button>
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-primary text-white mt-2 flex items-center justify-center gap-1 hover:bg-primary-dark transition-colors" onClick={() => handleNext(3)}>التالي <i className="fas fa-arrow-left"></i></button>
                </div>
              )}
              {step === 3 && (
                <div>
                  <h4 className="font-extrabold mb-2.5">بيانات المريض</h4>
                  <input type="text" className="w-full p-2 border border-gray-300 rounded-md mb-2 font-sans" placeholder="الاسم بالكامل" value={patient.name} onChange={e => setPatient({...patient, name: e.target.value})} />
                  <input type="tel" className="w-full p-2 border border-gray-300 rounded-md mb-2 font-sans text-left" dir="ltr" placeholder="رقم الهاتف" value={patient.phone} onChange={e => setPatient({...patient, phone: e.target.value})} />
                  <div className="flex gap-2 mb-2">
                    <input type="number" className="flex-1 p-2 border border-gray-300 rounded-md font-sans" placeholder="السن" value={patient.age} onChange={e => setPatient({...patient, age: e.target.value})} />
                    <input type="text" className="flex-[2] p-2 border border-gray-300 rounded-md font-sans" placeholder="العنوان" value={patient.address} onChange={e => setPatient({...patient, address: e.target.value})} />
                  </div>
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 mt-1 hover:bg-gray-300 transition-colors" onClick={() => setStep(2)}>رجوع</button>
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-primary text-white mt-2 flex items-center justify-center gap-1 hover:bg-primary-dark transition-colors" onClick={() => handleNext(4)}>التالي <i className="fas fa-arrow-left"></i></button>
                </div>
              )}
              {step === 4 && (
                <div>
                  <h4 className="font-extrabold mb-2.5">تأكيد الحجز</h4>
                  <label className="block mb-1 font-semibold">طريقة الدفع</label>
                  <select className="w-full p-2 border border-gray-300 rounded-md mb-2 font-sans" value={payment} onChange={e => setPayment(e.target.value)}>
                    <option value="cash">كاش</option><option value="visa">فيزا</option><option value="wallet">محفظة</option><option value="instapay">إنستاباي</option>
                  </select>
                  <div className="bg-gray-50 p-2.5 rounded-lg my-2.5 text-sm">
                    <div className="flex justify-between py-1 border-b border-gray-200"><span>الاسم:</span><span>{patient.name}</span></div>
                    <div className="flex justify-between py-1 border-b border-gray-200"><span>الخدمة:</span><span>{service?.name}</span></div>
                    <div className="flex justify-between py-1 font-black text-primary border-none"><span>الإجمالي:</span><span>{service?.price} ج</span></div>
                  </div>
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-gray-200 text-gray-800 mt-1 hover:bg-gray-300 transition-colors" onClick={() => setStep(3)} disabled={isLoading}>رجوع</button>
                  <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-[#2ecc71] text-white mt-2 flex items-center justify-center gap-1 hover:bg-green-600 transition-colors disabled:opacity-50" onClick={handleSubmit} disabled={isLoading}>
                    {isLoading ? <><i className="fas fa-spinner fa-spin"></i> جاري الإرسال...</> : <><i className="fas fa-check"></i> إرسال الطلب</>}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center p-5">
              <i className="fas fa-check-circle text-5xl text-[#2ecc71] mb-4"></i>
              <h3 className="text-xl font-bold mb-2">تم إرسال الطلب بنجاح!</h3>
              <p>رقم طلبك: <strong className="text-primary">{successRef}</strong></p>
              <div className="bg-gray-50 p-2.5 rounded-lg my-4 text-base font-bold text-accent">⏳ في الانتظار (سيتم تحديد رقم الدور عند التأكيد من الإدارة)</div>
              <button className="w-full p-2.5 border-none rounded-lg font-bold cursor-pointer font-sans bg-primary text-white mt-1 hover:bg-primary-dark transition-colors" onClick={clearForm}>طلب جديد</button>
            </div>
          )}
        </div>
      )}

      {tab === 'inq' && (
        <div className="bg-white rounded-xl p-5 shadow-sm">
          <div className="flex gap-1.5">
            <input type="text" className="flex-1 p-2 border border-gray-300 rounded-md font-sans text-left" dir="ltr" placeholder="أدخل رقم الطلب أو الاسم أو رقم الهاتف" value={inqRef} onChange={e => setInqRef(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleInquiry()} />
            <button className="px-4 py-2 border-none rounded-md font-bold cursor-pointer font-sans bg-primary text-white hover:bg-primary-dark transition-colors disabled:opacity-50 min-w-[80px]" onClick={handleInquiry} disabled={isLoading}>
              {isLoading ? <i className="fas fa-spinner fa-spin"></i> : 'بحث'}
            </button>
          </div>
          <div className="mt-4">
            {inqResult === 'not_found' && <p className="text-center text-accent font-bold">طلب غير موجود</p>}
            {inqResult && inqResult !== 'not_found' && (
              <div className="bg-gray-50 rounded-lg p-2.5">
                <div className={`font-bold mb-1 ${inqResult.status === 'pending' ? 'text-[#f39c12]' : inqResult.status === 'confirmed' ? 'text-[#2ecc71]' : 'text-accent'}`}>
                  {inqResult.status === 'pending' ? '⏳ قيد الانتظار' : inqResult.status === 'confirmed' ? '✅ مؤكد' : '❌ ملغي'}
                </div>
                <div>👤 {inqResult.name} | 📞 {inqResult.phone}</div>
                <div>📅 {inqResult.date} ⏰ {inqResult.time}</div>
                <div>🏥 {inqResult.serviceName} | 💰 {inqResult.price} ج</div>
                {inqResult.queue ? (
                  <div className="mt-2 text-lg font-black text-primary">🎫 رقم الدور: {inqResult.queue}</div>
                ) : (
                  <div className="mt-2 font-bold text-accent">⏳ لم يتم تحديد الدور بعد</div>
                )}
                {inqResult.secretaryReply && (
                  <div className="mt-2 p-2 bg-blue-50 text-primary font-bold rounded-md border border-blue-100">
                    💬 رد السكرتيرة: {inqResult.secretaryReply}
                  </div>
                )}
                {inqResult.status === 'cancelled' && inqResult.cancelReason && (
                  <div className="mt-2 p-2 bg-red-50 rounded-md text-red-700 font-bold">❌ سبب الإلغاء: {inqResult.cancelReason}</div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
