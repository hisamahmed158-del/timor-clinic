import React, { useState, useEffect } from 'react';
import { getQueueData, QueueData } from '../store';

export function PublicPages({ onOpenLogin, onOpenQueue, onOpenChat, onOpenBookingChoice }: { onOpenLogin: () => void, onOpenQueue: () => void, onOpenChat: () => void, onOpenBookingChoice: () => void }) {
  const [queueData, setQueueData] = useState<QueueData>(getQueueData());

  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'cl_q') {
        setQueueData(getQueueData());
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const isWorkingHours = () => {
    const now = new Date();
    return now.getHours() >= 15 && now.getHours() < 23;
  };

  const handlePhoneClick = () => {
    if (isWorkingHours()) {
      window.location.href = "tel:01006508388";
    } else {
      onOpenChat();
    }
  };

  return (
    <div id="site">
      <nav className="bg-white shadow-sm py-2 sticky top-0 z-[1000]">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({top:0, behavior:'smooth'})}>
            <img src="https://i.ibb.co/X08rH4R/image.png" alt="د. تيمور" className="w-10 h-10 rounded-full object-cover border-2 border-primary" onError={(e) => (e.currentTarget.src='https://ui-avatars.com/api/?name=د+تيمور&background=0D8ABC&color=fff')} />
            <div>
              <div className="font-extrabold text-primary-dark leading-tight text-[0.95rem]">د. تيمور عبد الحليم</div>
              <div className="text-[0.7rem] text-accent">أمراض القلب والأوعية الدموية</div>
            </div>
          </div>
          <div className="flex gap-2 items-center flex-wrap justify-center text-sm">
            <a href="#home" className="text-gray-700 font-semibold px-2 py-1 hover:text-primary transition-colors"><i className="fas fa-home"></i> الرئيسية</a>
            <a href="#about" className="text-gray-700 font-semibold px-2 py-1 hover:text-primary transition-colors"><i className="fas fa-user-md"></i> عن الدكتور</a>
            <a href="#queue" className="text-gray-700 font-semibold px-2 py-1 hover:text-primary transition-colors"><i className="fas fa-ticket-alt"></i> نظام الانتظار</a>
            <button onClick={onOpenBookingChoice} className="bg-primary text-white border-none rounded-full px-3 py-1 font-semibold hover:bg-primary-dark transition-colors cursor-pointer"><i className="fas fa-calendar-check"></i> حجز</button>
            <a href="#contact" className="text-gray-700 font-semibold px-2 py-1 hover:text-primary transition-colors"><i className="fas fa-phone"></i> تواصل</a>
            <button className="bg-gradient-primary text-white border-none px-3 py-1.5 rounded-full font-bold text-xs cursor-pointer flex items-center gap-1" onClick={onOpenLogin}>
              <i className="fas fa-lock"></i> إدارة العيادة
            </button>
          </div>
        </div>
      </nav>

      <div className="bg-gradient-primary text-white rounded-b-[30px] p-12 text-center mb-4" id="home">
        <h1 className="text-3xl md:text-2xl font-bold mb-2">عيادة أمراض القلب</h1>
        <p className="opacity-90 mb-6">د. تيمور عبد الحليم - رعاية طبية متخصصة</p>
        <div className="flex gap-2 justify-center flex-wrap">
          <button onClick={onOpenBookingChoice} className="px-5 py-2.5 border-none rounded-full font-bold text-sm cursor-pointer flex items-center gap-2 bg-white text-primary hover:bg-gray-100 transition-colors">
            <i className="fas fa-calendar-check"></i> احجز الآن
          </button>
          <button onClick={handlePhoneClick} className="px-5 py-2.5 rounded-full font-bold text-sm cursor-pointer flex items-center gap-2 bg-white/20 text-white border border-white/40 hover:bg-white/30 transition-colors">
            <i className="fas fa-phone"></i> اتصل بالعيادة
          </button>
        </div>
      </div>

      <section id="about" className="p-8 max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl p-10 shadow-lg my-8 mx-auto max-w-2xl text-center">
          <img src="https://i.ibb.co/X08rH4R/image.png" alt="د. تيمور عبد الحليم" className="w-44 h-44 rounded-full border-4 border-primary shadow-[0_8px_25px_rgba(13,110,253,0.3)] object-cover block mx-auto mb-6" onError={(e) => (e.currentTarget.src='https://ui-avatars.com/api/?name=د+تيمور&background=0D8ABC&color=fff&size=300')} />
          <h2 className="text-3xl font-black text-primary-dark mb-2">د. تيمور عبد الحليم</h2>
          <div className="text-accent font-bold text-lg mb-6">أستاذ أمراض القلب والأوعية الدموية</div>
          <div className="bg-gray-50 p-6 rounded-xl mt-4 text-right leading-relaxed">
            <h4 className="text-primary mb-4 text-lg font-bold"><i className="fas fa-info-circle ml-2"></i> نبذة عن الدكتور</h4>
            <ul className="list-none p-0">
              <li className="py-2 border-b border-gray-200"><i className="fas fa-graduation-cap text-primary ml-2 w-5"></i> أستاذ أمراض القلب والأوعية الدموية</li>
              <li className="py-2 border-b border-gray-200"><i className="fas fa-certificate text-primary ml-2 w-5"></i> عضو الجمعية المصرية للقلب</li>
              <li className="py-2 border-b border-gray-200"><i className="fas fa-hospital text-primary ml-2 w-5"></i> خبرة واسعة في علاج أمراض القلب</li>
              <li className="py-2 border-b border-gray-200"><i className="fas fa-map-marker-alt text-primary ml-2 w-5"></i> العيادة: المحلة الكبرى - أمام العيادة الشعبية<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;فوق دار القلب - الدور الثامن</li>
              <li className="py-2"><i className="fas fa-clock text-primary ml-2 w-5"></i> مواعيد العمل: يومياً من 5 مساءً حتى 11 مساءً</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="services" className="p-8 max-w-6xl mx-auto">
        <div className="text-center font-black text-2xl mb-5 text-[#1a1a2e]">الخدمات والأسعار</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-5 shadow-sm text-center transition-transform hover:-translate-y-1">
            <i className="fas fa-user-md text-3xl mb-2 text-primary"></i><h3 className="font-bold">كشف أول</h3><div className="text-2xl font-black text-primary my-2">300 ج</div>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-sm text-center transition-transform hover:-translate-y-1">
            <i className="fas fa-redo text-3xl mb-2 text-accent"></i><h3 className="font-bold">كشف إعادة</h3><div className="text-2xl font-black text-primary my-2">150 ج</div>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-sm text-center transition-transform hover:-translate-y-1">
            <i className="fas fa-heartbeat text-3xl mb-2 text-[#2ecc71]"></i><h3 className="font-bold">كشف + رسم قلب</h3><div className="text-2xl font-black text-primary my-2">350 ج</div>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-sm text-center transition-transform hover:-translate-y-1">
            <i className="fas fa-file-medical text-3xl mb-2 text-[#f39c12]"></i><h3 className="font-bold">إعادة + رسم قلب</h3><div className="text-2xl font-black text-primary my-2">200 ج</div>
          </div>
        </div>
      </section>

      <section id="queue" className="p-8 max-w-6xl mx-auto">
        <div className="text-center font-black text-2xl mb-5 text-[#1a1a2e]">🎫 نظام انتظار الكشف</div>
        <div className="bg-gradient-dark text-white rounded-2xl p-8 text-center mb-8 shadow-xl">
          <div className="flex items-center justify-center gap-1.5 text-[#2ecc71] font-bold mb-4">
            <span className="w-2 h-2 bg-[#2ecc71] rounded-full animate-pulse-green"></span> تحديث يدوي من الإدارة
          </div>
          <div className="flex justify-center gap-12 flex-wrap">
            <div>
              <div className="text-lg">🔴 الدور الحالي</div>
              <div className="text-5xl font-black my-1 transition-all">{queueData.cNum}</div>
              <div className="text-base text-gray-300 mt-1 min-h-[24px]">{queueData.cName}</div>
            </div>
            <div className="w-0.5 bg-white/30 self-stretch hidden md:block"></div>
            <div>
              <div className="text-lg">🟡 الدور القادم</div>
              <div className="text-5xl font-black my-1 transition-all">{queueData.nNum}</div>
              <div className="text-base text-gray-300 mt-1 min-h-[24px]">{queueData.nName}</div>
            </div>
          </div>
          <p className="mt-4 text-xs opacity-60">
            <button onClick={onOpenQueue} className="bg-white/20 border-none text-white px-3 py-1.5 rounded-full cursor-pointer mt-2 hover:bg-white/30 transition-colors">
              <i className="fas fa-tv"></i> فتح الشاشة التفاعلية
            </button>
          </p>
        </div>
      </section>
    </div>
  );
}
