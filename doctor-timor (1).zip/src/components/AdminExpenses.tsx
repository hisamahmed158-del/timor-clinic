import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import { Expense, saveFirebaseExpense, deleteFirebaseExpense, User } from '../store';

export function AdminExpenses({ onNotify, user }: { onNotify: (m: string, e?: boolean) => void, user: User }) {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [search, setSearch] = useState('');
  const [filterDate, setFilterDate] = useState('');
  
  const [form, setForm] = useState<Partial<Expense>>({});
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'expenses'), (snap) => {
      const e: Expense[] = [];
      snap.forEach(d => e.push(d.data() as Expense));
      setExpenses(e.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    });
    return () => unsub();
  }, []);

  const handleSave = async () => {
    if (!form.description || !form.amount || !form.date) {
      onNotify('يرجى إكمال وصف وقيمة وتاريخ المصروف', true);
      return;
    }
    setIsLoading(true);
    try {
      const id = form.id || 'EXP-' + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase();
      const newE: Expense = {
        id,
        description: form.description.trim(),
        amount: Number(form.amount),
        date: form.date,
        createdAt: form.createdAt || new Date().toISOString(),
        addedBy: form.addedBy || user.name
      };
      await saveFirebaseExpense(newE);
      onNotify('تم تسجيل المصروف بنجاح 💰');
      setShowModal(false);
      setForm({});
    } catch(e: any) {
      onNotify(e.message || 'خطأ في الحفظ', true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string, desc: string) => {
    if (window.confirm(`هل أنت متأكد من حذف هذا المصروف (${desc})؟`)) {
       await deleteFirebaseExpense(id);
       onNotify('تم الحذف');
    }
  };

  const openAdd = () => {
    setForm({ date: new Date().toISOString().split('T')[0] });
    setShowModal(true);
  };

  const openEdit = (e: Expense) => {
    setForm(e);
    setShowModal(true);
  };

  const filtered = expenses.filter(e => {
    const matchSearch = !search || e.description.toLowerCase().includes(search.toLowerCase());
    const matchDate = !filterDate || e.date === filterDate;
    return matchSearch && matchDate;
  });

  const totalFiltered = filtered.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 min-h-[60vh]">
      <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
        <h3 className="font-extrabold text-xl text-primary"><i className="fas fa-hand-holding-usd text-red-500"></i> مصروفات العيادة</h3>
        <button className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-lg shadow-sm border-none cursor-pointer flex items-center gap-2 transition-colors" onClick={openAdd}>
          <i className="fas fa-plus"></i> إضافة مصروف
        </button>
      </div>

      <div className="mb-4 flex flex-col md:flex-row gap-3">
        <div className="flex-[2] relative">
          <input 
            type="text" 
            placeholder="بحث بالوصف..." 
            className="w-full p-3 pr-10 border border-gray-300 rounded-lg outline-none focus:border-primary"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <i className="fas fa-search absolute right-3 top-3.5 text-gray-400"></i>
        </div>
        <div className="flex-1 flex gap-2">
          <input 
            type="date" 
            className="w-full p-3 border border-gray-300 rounded-lg outline-none focus:border-primary"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
          />
          {filterDate && (
            <button className="bg-gray-100 text-gray-600 px-3 border-none rounded-lg font-bold cursor-pointer hover:bg-gray-200" onClick={() => setFilterDate('')}>الكل</button>
          )}
          <button className="bg-blue-50 text-blue-600 px-3 border-none rounded-lg font-bold cursor-pointer whitespace-nowrap" onClick={() => setFilterDate(new Date().toISOString().split('T')[0])}>اليوم</button>
        </div>
      </div>

      <div className="mb-4 bg-red-50 border border-red-100 p-4 rounded-lg flex justify-between items-center text-red-800">
        <div className="font-bold">إجمالي مصروفات {filterDate ? `يوم ${filterDate}` : 'الفترة الحالية'}:</div>
        <div className="text-2xl font-black">{totalFiltered} <span className="text-sm">جنيه</span></div>
      </div>

      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-gray-500">لا توجد مصروفات مسجلة.</div>
        ) : (
          filtered.map((e) => (
            <div key={e.id} className="border border-gray-200 rounded-lg p-3 hover:border-red-300 transition-colors flex justify-between items-center gap-3 bg-white">
              <div className="flex-1">
                <div className="font-bold text-lg">{e.description}</div>
                <div className="text-sm text-gray-500">
                  <i className="far fa-calendar-alt"></i> {e.date} | بواسطة: {e.addedBy}
                </div>
              </div>
              
              <div className="text-xl font-bold text-red-500 ml-4 font-mono dir-ltr shrink-0">
                {e.amount} ج.م
              </div>

              <div className="flex gap-2 shrink-0">
                 <button onClick={() => openEdit(e)} className="bg-blue-50 text-blue-600 hover:bg-blue-100 border-none w-8 h-8 rounded flex items-center justify-center cursor-pointer transition-colors"><i className="fas fa-edit"></i></button>
                 <button onClick={() => handleDelete(e.id, e.description)} className="bg-red-50 text-red-600 hover:bg-red-100 border-none w-8 h-8 rounded flex items-center justify-center cursor-pointer transition-colors"><i className="fas fa-trash"></i></button>
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/60 z-[9999] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-md" dir="rtl">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl">
              <h3 className="font-extrabold text-lg m-0">{form.id ? '✏️ تعديل مصروف' : '💸 إضافة مصروف جديد'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-red-500 bg-transparent border-none text-xl cursor-pointer"><i className="fas fa-times"></i></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-bold mb-1 text-gray-700">التفاصيل (فيما صُرف؟) <span className="text-red-500">*</span></label>
                <input type="text" placeholder="مثال: مناديل ومطهرات" className="w-full p-3 border border-gray-300 rounded outline-none focus:border-red-400" value={form.description || ''} onChange={(e)=>setForm({...form, description: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-bold mb-1 text-gray-700">القيمة بالجنيه <span className="text-red-500">*</span></label>
                <input type="number" placeholder="0" className="w-full p-3 border border-gray-300 rounded outline-none focus:border-red-400 font-mono text-xl" value={form.amount || ''} onChange={(e)=>setForm({...form, amount: e.target.value ? Number(e.target.value) : undefined})} />
              </div>
              <div>
                <label className="block text-sm font-bold mb-1 text-gray-700">التاريخ <span className="text-red-500">*</span></label>
                <input type="date" className="w-full p-3 border border-gray-300 rounded outline-none focus:border-red-400" value={form.date || ''} onChange={(e)=>setForm({...form, date: e.target.value})} />
              </div>
            </div>
            
            <div className="p-4 border-t border-gray-100 bg-gray-50 rounded-b-xl flex justify-end gap-2">
              <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded font-bold cursor-pointer border-none hover:bg-gray-300" onClick={() => setShowModal(false)} disabled={isLoading}>إلغاء</button>
              <button className="px-5 py-2 bg-red-500 text-white rounded font-bold cursor-pointer border-none hover:bg-red-600 disabled:opacity-50" onClick={handleSave} disabled={isLoading}>
                 {isLoading ? 'جاري الحفظ...' : 'متابعة'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
